package DBDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import DAO.CustomerDAO;
import Data_Base.Connection_Pool;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import java_beans.Coupon;
import java_beans.Customer;

public class CustomerDBDAO implements CustomerDAO {
	@Override
	public void createCustomer(Customer Customer) throws ConnectionPoolException, DAOException {
		String sql = "INSERT INTO Customer (CUST_NAME,PASSWORD) VALUES (?,?)";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Customer.getCustName());
			pstmt.setString(2, Customer.getPassword());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to create new customer in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public void removeCustomer(Customer Customer) throws ConnectionPoolException, DAOException {
		String sql = "DELETE FROM Customer WHERE ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			Iterator<Coupon> Coupon = new CouponDBDAO().getAllCouponsOfCustID(Customer.getId()).iterator();
			while (Coupon.hasNext()) {
				{
					this.removeCustomerCoupon(Coupon.next(), Customer);
				}
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, Customer.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to remove customer from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public void updateCustomer(Customer Customer) throws ConnectionPoolException, DAOException {
		String sql = "UPDATE Customer SET PASSWORD=? WHERE ID=? AND CUST_NAME=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Customer.getPassword());
			pstmt.setLong(2, Customer.getId());
			pstmt.setString(3, Customer.getCustName());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to update customer in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public Customer getCustomer(long id) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Customer WHERE ID=?";
		Customer customer = null;
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				customer = new Customer();
				customer.setId(id);
				customer.setCustName(rs.getString(2));
				customer.setPassword(rs.getString(3));
				customer.setCoupons(new CouponDBDAO().getAllCouponsOfCustID(id));
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get customer from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return customer;
	}

	@Override
	public Collection<Coupon> getAvialableCouponsForPurchase(Customer customer)
			throws ConnectionPoolException, DAOException {
		String sql = "select *  from Coupon";
		CouponDBDAO couponDBDAO = new CouponDBDAO();
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Coupon coupon = new Coupon();
				couponDBDAO.FillCoupon(coupon, rs);
				if (couponDBDAO.isAvailableForPurchse(coupon, customer)) {
					coupons.add(coupon);

				}
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get all coupons from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		System.out.println("*************" + coupons);

		return coupons;
	}

	@Override
	public Collection<Customer> getAllCustomers() throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Customer";
		Collection<Customer> customers = new HashSet<>();
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Customer customer = new Customer();
				customer.setId(rs.getLong(1));
				customer.setCustName(rs.getString(2));
				customer.setPassword(rs.getString(3));
				customer.setCoupons(new CouponDBDAO().getAllCouponsOfCustID(rs.getLong(1)));
				customers.add(customer);
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get all customers from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return customers;
	}

	@Override
	public Collection<Coupon> getCouponsPerCustomer(long cust_id) throws ConnectionPoolException, DAOException {
		CouponDBDAO coupon = new CouponDBDAO();
		return coupon.getAllCouponsOfCustID(cust_id);
	}

	@Override
	public boolean login(String custName, String password) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Customer WHERE CUST_NAME=? AND PASSWORD=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, custName);
			pstmt.setString(2, password);
			pstmt.executeQuery();
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to confirm login credentials in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
	}

	@Override
	public void purchaseCoupon(Coupon Coupon, Customer cust) throws ConnectionPoolException, DAOException {
		String sql = "INSERT INTO Customer_Coupon VALUES (?,?)";
		Coupon UpToDateCoup = new CouponDBDAO().getCoupon(Coupon.getId());
		System.out.println(UpToDateCoup.toString());
		if (UpToDateCoup.getAmount() > 0) {
			Connection con = Connection_Pool.getInstance().getConnection();
			try {

				if (con == null) {
					ConnectionPoolException interapt = new ConnectionPoolException(
							"Connection Pool has been interrupted");
					throw interapt;
				}

				PreparedStatement pstmt = con.prepareStatement(sql);
				pstmt.setLong(1, cust.getId());
				pstmt.setLong(2, UpToDateCoup.getId());
				pstmt.executeUpdate();
				UpToDateCoup.setAmount(UpToDateCoup.getAmount() - 1);
				new CouponDBDAO().updateCoupon(UpToDateCoup);

			} catch (SQLException e) {
				DAOException DaoException = new DAOException(
						"Unable to purchase coupon in DB-you might have a connection or Query problem, please check your url path and your Query");
				throw DaoException;
			} finally {
				Connection_Pool.getInstance().releaseConn(con);
			}
		} else {
			DAOException DaoException = new DAOException(
					"Unable to purchase coupon in DB-There are not enough amount of coupons");
			throw DaoException;
		}
	}

	@Override
	public void removeCustomerCoupon(Coupon Coupon, Customer Customer) throws ConnectionPoolException, DAOException {
		String sql = "DELETE FROM Customer_Coupon WHERE COUPON_ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, Coupon.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to remove coupon in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
	}

	@Override
	public Customer getCustomerByName(String name) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Customer WHERE CUST_NAME=?";
		Customer customer = null;
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				customer = new Customer();
				customer.setId(rs.getLong(1));
				customer.setCustName(rs.getString(2));
				customer.setPassword(rs.getString(3));
				customer.setCoupons(new CouponDBDAO().getAllCouponsOfCustID(rs.getLong(1)));
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get customer from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return customer;
	}

}
