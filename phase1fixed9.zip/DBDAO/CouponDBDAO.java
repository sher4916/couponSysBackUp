package DBDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import DAO.CouponDAO;
import Data_Base.Connection_Pool;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class CouponDBDAO implements CouponDAO {

	@Override
	public void createCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException {
		String sql = "INSERT INTO Coupon (TITLE,START_DATE,END_DATE,AMOUNT,TYPE,MESSAGE,PRICE,IMAGE) VALUES (?,?,?,?,?,?,?,?)";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {

			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Coupon.getTitle());
			pstmt.setDate(2, new java.sql.Date(Coupon.getStartDate().getTime()));
			pstmt.setDate(3, new java.sql.Date(Coupon.getEndDate().getTime()));
			pstmt.setInt(4, Coupon.getAmount());
			pstmt.setString(5, Coupon.getType().toString());
			pstmt.setString(6, Coupon.getMessage());
			pstmt.setDouble(7, Coupon.getPrice());
			pstmt.setString(8, Coupon.getImage());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to create new coupon in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public void removeCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException {
		String sql = "DELETE FROM Coupon WHERE ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
				throw interapt;
			}
			Iterator<Customer> cust = this.getAllCustomersPerCouponId(Coupon).iterator();
			while (cust.hasNext()) {
				new CustomerDBDAO().removeCustomerCoupon(Coupon, cust.next());
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, Coupon.getId());
			pstmt.executeUpdate();
			sql = "DELETE FROM Company_Coupon WHERE COUPON_ID=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, Coupon.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to remove coupon from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	public void FillPstmtCoupon(Coupon Coupon, PreparedStatement pstmt) throws SQLException {
		pstmt.setLong(1, Coupon.getId());
		pstmt.setString(2, Coupon.getTitle());
		pstmt.setDate(3, new java.sql.Date(Coupon.getStartDate().getTime()));
		pstmt.setDate(4, new java.sql.Date(Coupon.getEndDate().getTime()));
		pstmt.setInt(5, Coupon.getAmount());
		pstmt.setString(6, Coupon.getType().toString());
		pstmt.setString(7, Coupon.getMessage());
		pstmt.setDouble(8, Coupon.getPrice());
		pstmt.setString(9, Coupon.getImage());

	}

	@Override
	public void updateCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException {
		String sql = "UPDATE Coupon SET START_DATE=?, END_DATE=?,AMOUNT=?, TYPE=?,MESSAGE=?,PRICE=?, IMAGE=? WHERE ID=? AND TITLE=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setDate(1, new java.sql.Date(Coupon.getStartDate().getTime()));
			pstmt.setDate(2, new java.sql.Date(Coupon.getEndDate().getTime()));
			pstmt.setInt(3, Coupon.getAmount());
			pstmt.setString(4, Coupon.getType().toString());
			pstmt.setString(5, Coupon.getMessage());
			pstmt.setDouble(6, Coupon.getPrice());
			pstmt.setString(7, Coupon.getImage());
			pstmt.setLong(8, Coupon.getId());
			pstmt.setString(9, Coupon.getTitle());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to update coupon in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public Coupon getCoupon(long id) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Coupon WHERE ID =?";
		Connection con = Connection_Pool.getInstance().getConnection();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs;
			rs = pstmt.executeQuery();
			if (rs.next()) {
				Coupon coupon = new Coupon();
				FillCoupon(coupon, rs);
				return coupon;
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupon from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return null;
	}

	@Override
	public Collection<Coupon> getAllCoupons() throws ConnectionPoolException, DAOException {
		String sql = "select *  from Coupon";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Coupon coupon = new Coupon();
				FillCoupon(coupon, rs);
				coupons.add(coupon);
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get all coupons from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return coupons;
	}

	@Override
	public Collection<Coupon> getCouponByType(CouponType couponType) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Coupon where TYPE =?";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, couponType.toString());
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Coupon coupon = new Coupon();
				FillCoupon(coupon, rs);
				coupons.add(coupon);
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupon from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return coupons;
	}

	@Override
	public Collection<Coupon> getAllCouponsOfCompenyID(long id) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Company_Coupon where COMP_ID =?";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				// Coupon coupon = this.getCoupon(rs.getLong(2));
				// coupons.add(coupon);
				coupons.add(new CouponDBDAO().getCoupon(rs.getLong(2)));
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupon from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return coupons;
	}

	@Override
	public Collection<Coupon> getAllCouponsOfCustID(long cust_id) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Customer_Coupon where CUST_ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, cust_id);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				coupons.add(new CouponDBDAO().getCoupon(rs.getLong(2)));
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupon from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return coupons;
	}

	@Override
	public void FillCoupon(Coupon coupon, ResultSet rs) throws SQLException {

		coupon.setId(rs.getLong(1));
		coupon.setTitle(rs.getString(2));
		coupon.setStartDate(rs.getDate(3));
		coupon.setEndDate(rs.getDate(4));
		coupon.setAmount(rs.getInt(5));
		coupon.setType(rs.getString(6));
		coupon.setMessage(rs.getString(7));
		coupon.setPrice(rs.getDouble(8));
		coupon.setImage(rs.getString(9));

	}

	@Override
	public Collection<Customer> getAllCustomersPerCouponId(Coupon coupon) throws ConnectionPoolException, DAOException {
		return this.getAllCustomersPerCouponId(coupon.getId());
	}

	@Override
	public Collection<Coupon> getAllCouponsOfCustID(Customer customer) throws ConnectionPoolException, DAOException {
		return this.getAllCouponsOfCustID(customer.getId());
	}

	@Override
	public Collection<Coupon> getAllCouponsOfCompenyID(Company company) throws ConnectionPoolException, DAOException {
		return this.getAllCouponsOfCompenyID(company.getId());
	}

	@Override
	public Collection<Customer> getAllCustomersPerCouponId(long id) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Customer_Coupon where COUPON_ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Customer> Custs = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Custs.add(new CustomerDBDAO().getCustomer(rs.getLong(1)));
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get customers from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return Custs;
	}

	@Override
	public Collection<Coupon> getAllCouponsPerCustIDByType(long id, CouponType couponType)
			throws ConnectionPoolException, DAOException {
		String sql = "select *  from Coupon where TYPE =? AND CUST_ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, couponType.toString());
			pstmt.setLong(2, id);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Coupon coupon = new Coupon();
				FillCoupon(coupon, rs);
				coupons.add(coupon);
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupons from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return coupons;
	}

	@Override
	public Collection<Coupon> getAllCouponsByPrice(Double price) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Coupon where AND PRICE<?";
		Connection con = Connection_Pool.getInstance().getConnection();
		Collection<Coupon> coupons = new HashSet<>();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setDouble(1, price);
			ResultSet rs;
			rs = pstmt.executeQuery();
			while (rs.next()) {
				coupons.add(new CouponDBDAO().getCoupon(rs.getLong(2)));
			}

		} catch (SQLException e) {
			System.out.println(e);
			DAOException DaoException = new DAOException(
					"Unable to get customers from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return coupons;
	}

	@Override
	public boolean CouponIsBelongToCompany(Coupon Coupon, long id) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Company_Coupon where COMP_ID =? AND COUPON_ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			pstmt.setLong(2, Coupon.getId());
			ResultSet rs;
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupons from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public Coupon getCouponByTitle(String Title) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Coupon WHERE TITLE =?";
		Connection con = Connection_Pool.getInstance().getConnection();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, Title);
			ResultSet rs;
			rs = pstmt.executeQuery();
			if (rs.next()) {
				Coupon coupon = new Coupon();
				FillCoupon(coupon, rs);
				return coupon;
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupons from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

		return null;
	}

	public boolean isAvailableForPurchse(Coupon coupon, Customer customer)
			throws ConnectionPoolException, DAOException {
		if ((coupon.getAmount() > 0) && (!CouponIsBelongToCustomer(coupon, customer.getId()))
				&& (coupon.getEndDate().after(new java.sql.Date(new java.util.Date().getTime())))) {
			return true;
		}

		return false;
	}

	@Override
	public boolean CouponIsBelongToCustomer(Coupon Coupon, long id) throws ConnectionPoolException, DAOException {
		String sql = "select *  from Customer_Coupon where CUST_ID =? AND COUPON_ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		if (con == null) {
			ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
			throw interapt;
		}

		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			pstmt.setLong(2, Coupon.getId());
			ResultSet rs;
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get coupons from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

}
