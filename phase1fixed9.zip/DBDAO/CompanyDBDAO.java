package DBDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import DAO.CompanyDAO;
import Data_Base.Connection_Pool;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import java_beans.Company;
import java_beans.Coupon;

public class CompanyDBDAO implements CompanyDAO {

	@Override
	public void createCompany(Company company) throws ConnectionPoolException, DAOException {
		String sql = "INSERT INTO Company(COMP_NAME,password,EMAIL) VALUES (?,?,?)";
		Connection con = Connection_Pool.getInstance().getConnection();
		//TODO return this to the try and catch
		
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			// pstmt.setLong(1, company.getId());
			pstmt.setString(1, company.getCompName());
			pstmt.setString(2, company.getPassword());
			pstmt.setString(3, company.getEmail());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to create new company in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public void removeCompany(Company company) throws ConnectionPoolException, DAOException {
		String sql = "DELETE FROM Company WHERE ID=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			Iterator<Coupon> Coupon = new CouponDBDAO().getAllCouponsOfCompenyID(company.getId()).iterator();
			while (Coupon.hasNext()) {
				Coupon coupon = Coupon.next();
				new CouponDBDAO().removeCoupon(coupon);
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, company.getId());
			pstmt.executeUpdate();
			sql = "DELETE FROM Company_Coupon WHERE COMP_ID=?";
			pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, company.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to remove company from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public void updateCompany(Company company) throws ConnectionPoolException, DAOException {
		String sql = "UPDATE Company SET PASSWORD=?,EMAIL=? WHERE ID=? AND COMP_NAME=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, company.getPassword());
			pstmt.setString(2, company.getEmail());
			pstmt.setLong(3, company.getId());
			pstmt.setString(4, company.getCompName());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to update company in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	//return null if not found any company
	@Override
	public Company getCompany(long id) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Company WHERE ID=?";
		Company company = null;
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, id);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				company = new Company();
				company.setId(id);
				company.setCompName(rs.getString(2));
				company.setPassword(rs.getString(3));
				company.setEmail(rs.getString(4));
				company.setCoupons(new CouponDBDAO().getAllCouponsOfCompenyID(id));
			}
			

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get company from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return company;
	}

	@Override
	public Collection<Company> getAllCompanies() throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Company";
		Collection<Company> companies = new HashSet<>();
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				Company company = new Company();
				company.setId(rs.getLong(1));
				company.setCompName(rs.getString(2));
				company.setPassword(rs.getString(3));
				company.setEmail(rs.getString(4));
				company.setCoupons(new CouponDBDAO().getAllCouponsOfCompenyID(company.getId()));
				companies.add(company);
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get All Companies from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return companies;
	}

	@Override
	public Collection<Coupon> getCouponsPerCompany(long id) throws ConnectionPoolException, DAOException {
		CouponDBDAO coupon = new CouponDBDAO();
		return coupon.getAllCouponsOfCompenyID(id);
	}

	@Override
	public boolean login(String compName, String password) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Company WHERE COMP_NAME=? AND PASSWORD=?";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, compName);
			pstmt.setString(2, password);
			pstmt.executeQuery();
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				return true;
			} else {
				return false;
			}

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to confirm login credentials in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}

	}

	@Override
	public void CreateCoupon(Coupon Coupon, Company comp) throws ConnectionPoolException, DAOException {
		String sql = "INSERT INTO Company_Coupon VALUES (?,?)";
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, comp.getId());
			pstmt.setLong(2, Coupon.getId());
			pstmt.executeUpdate();

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to create coupon in DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
	}

	//return null if not found any company
	@Override
	public Company getCompenyByName(String name) throws ConnectionPoolException, DAOException {
		String sql = "SELECT *  FROM Company WHERE COMP_NAME=?";
		Company company = null;
		Connection con = Connection_Pool.getInstance().getConnection();
		try {
			if (con == null) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interrupted");
				throw interapt;
			}
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {

				company = new Company();
				company.setId(rs.getLong(1));
				company.setCompName(rs.getString(2));
				company.setPassword(rs.getString(3));
				company.setEmail(rs.getString(4));
				company.setCoupons(new CouponDBDAO().getAllCouponsOfCompenyID(company.getId()));

			} 

		} catch (SQLException e) {
			DAOException DaoException = new DAOException(
					"Unable to get company from DB-you might have a connection or Query problem, please check your url path and your Query");
			throw DaoException;
		} finally {
			Connection_Pool.getInstance().releaseConn(con);
		}
		return company;
	}
}
