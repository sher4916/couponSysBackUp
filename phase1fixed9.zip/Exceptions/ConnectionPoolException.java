package Exceptions;

public class ConnectionPoolException extends CouponSystemException {

	private static final long serialVersionUID = 1L;

	public ConnectionPoolException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public ConnectionPoolException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
