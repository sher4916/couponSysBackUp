package Exceptions;

public class DAOException extends CouponSystemException {

	private static final long serialVersionUID = 1L;

	public DAOException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public DAOException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */

}
