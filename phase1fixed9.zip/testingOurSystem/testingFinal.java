package testingOurSystem;

import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Date;
import java.util.Enumeration;

import Data_Base.Connection_Pool;
import Data_Base.DropAllTables;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import Facade.AdminFacade;
import Facade.ClientType;
import Facade.CompanyFacade;
import Facade.CouponSystem;
import Facade.CustomerFacade;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class testingFinal {

	public static void main(String[] args) {
		Enumeration<Driver> en = DriverManager.getDrivers();

		// print drivers
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement().getClass().getName());
		}
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		try {
			Class.forName(driverName);
			System.out.println(driverName + " loaded successfuly");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			DropAllTables.dropTables();
			System.out.println("all the tabels have been droped");
			Data_Base.create_tables3.main(null);
			System.out.println("all the tabels have been created");
			CouponSystem Csys = CouponSystem.getInstance();
			AdminFacade admin = (AdminFacade) Csys.login("admin", "1234", ClientType.Admin);
			System.out.println(admin);
			admin.createCompany(new Company(101L, "Pink My Ride", "Qdx123421122", "admin@pink.com"));
			CompanyFacade company1 = (CompanyFacade) Csys.login("Pink My Ride", "Qdx123421122", ClientType.Company); // company.g
			System.out.println(company1);
			// long id, String title, Date startDate, Date endDate, int amount,
			// CouponType type, String message,double price, String image) {
			// 1st coupon-valid date, belongs to company1
			Coupon coupon1 = new Coupon(1L, "all free", new Date(), new Date(new Date().getTime() + 86400000), 50,
					CouponType.FOOD, "no more hungery people", 0.00, "no image");
			company1.createCoupon(coupon1);
			//Connection_Pool.getInstance().closeAllConnections();
			System.out.println("the new coupon" + company1);
			// admin.createCustomer(new Customer(0L, "shahaf",
			// "qGDGJKASDFGAKJDGFJADSDFSSXCCG1"));
			// CustomerFacade customer = (CustomerFacade) Csys.login("shahaf",
			// "qGDGJKASDFGAKJDGFJADSDFSSXCCG1",
			// ClientType.Customer);
			// customer.purchaseCoupon(coupon1);
			// System.out.println(customer);
			System.out.println(company1);
			System.out.println(coupon1);
			System.out.println("show all coupon" + company1.getAllCoupon());
			// 2nd coupon-expired, belongs to company1
			Coupon coupon2 = new Coupon(2L, "all free2", new Date(), new Date(new Date().getTime() + 86400000), 50,
					CouponType.FOOD, "no more hungery people", 0.00, "no image");
			company1.createCoupon(coupon2);
			
			System.out.println("show all coupon" + company1.getAllCoupon());
			// customer.purchaseCoupon(coupon2);
			System.out.println("show all coupon" + company1.getAllCoupon());

			// admin.DeleteAllCouponsOutOfDate();
			// System.out.println("show all coupon" + company.getAllCoupon());
			// 3rd coupon-expired, belongs to company1
			// it shouldn't add coupon 3 because it has the same title as coupon
			// 2
			/*
			Coupon coupon3 = new Coupon(3L, "all free2", new Date(), new Date(new Date().getTime() + (86400000 * 3)),
					50, CouponType.FOOD, "no more hungery people", 0.00, "no image");
			company1.createCoupon(coupon3);
			*/
			
			System.out.println("show all coupon" + company1.getAllCoupon());
			// 2nd company
			admin.createCompany(new Company(102L, "Notey", "1234", "admin@notey.com"));
			CompanyFacade company2 = (CompanyFacade) Csys.login("Notey", "1234", ClientType.Company); // company.g
			System.out.println(company2);
			// 3rd company
			admin.createCompany(new Company(103L, "sher Line", "1234", "admin@sherline.com"));
			CompanyFacade company3 = (CompanyFacade) Csys.login("sher Line", "1234", ClientType.Company); // company.g
			System.out.println(company3);
			// 4th coupon-valid , belongs to company2
			// it should add coupon 4 because it has a different title
			Coupon coupon4 = new Coupon(4L, "all free4", new Date(), new Date(new Date().getTime() + (86400000 * 3)),
					50, CouponType.FOOD, "no more hungery people", 0.00, "no image");
			company2.createCoupon(coupon4);
			System.out.println("admin shows all coupons" + admin.getAllCoupons());
			System.out.println("show all coupon company1" + company1.getAllCoupon());
			System.out.println("show all coupon company2" + company2.getAllCoupon());
			System.out.println(company2);
			
			System.out.println(admin.getAllCustomer());
			admin.createCustomer(new Customer(0L, "shahaf", "12312312"));
			CustomerFacade customer1 = (CustomerFacade) Csys.login("shahaf", "12312312", ClientType.Customer);
			Coupon c = company1.getAllCoupon().iterator().next();
			System.out.println(c);
			//customer1.purchaseCoupon(c);
			//customer1.purchaseCoupon(c);

			System.out.println(customer1);

			System.out.println(admin.getAllCustomer());
			System.out.println(admin.getAllCompanies());
		} catch (ConnectionPoolException | DAOException | FacadeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
