package testingOurSystem;

import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Date;
import java.util.Enumeration;

import Data_Base.Connection_Pool;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import Facade.ClientType;
import Facade.CompanyFacade;
import Facade.CouponSystem;
import java_beans.Coupon;
import java_beans.CouponType;

public class addingcoupons {
	public static void main(String[] args) throws ConnectionPoolException, DAOException, FacadeException {
		Enumeration<Driver> en = DriverManager.getDrivers();

		// print drivers
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement().getClass().getName());
		}
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		try {
			Class.forName(driverName);
			System.out.println(driverName + " loaded successfuly");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		Facade.DailyThread DailyThread;
		try {
			// Connection_Pool.getInstance().CreateDBandConnections("jdbc:derby://localhost:1527/coupondb",
			// 10);
			Connection_Pool.getInstance().getConnection();
		} catch (ConnectionPoolException e1) {
			ConnectionPoolException cantConnect = new ConnectionPoolException(
					"Unable to connect to the database, please check your url path");
			throw cantConnect;
		}
		// Open the Coupon System
		CouponSystem Csys = CouponSystem.getInstance();
		// prepare the Daily Thread to run
		DailyThread = new Facade.DailyThread("admin", "1234");
		// login as admin
		CompanyFacade company1 = (CompanyFacade) Csys.login("shahaf", "1234", ClientType.Company);
		Coupon Coupon = new Coupon(777, "sun", new java.sql.Date(new Date().getTime()),
				new java.sql.Date(new Date().getTime() + (20 * 86400000)), 60, CouponType.SPORTS, "peace out", 33.33,
				"you.jpg");

		try {
			company1.createCoupon(Coupon);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Coupon Coupon4 = new Coupon(777, "sun1", new java.sql.Date(new Date().getTime()),
				new java.sql.Date(new Date().getTime() + (13 * 86400000)), 60, CouponType.SPORTS, "peace out", 33.33,
				"you.jpg");
		try {
			company1.createCoupon(Coupon4);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Coupon Coupon1 = new Coupon(777, "sun2", new java.sql.Date(new Date().getTime()),
				new java.sql.Date(new Date().getTime() + (13 * 86400000)), 60, CouponType.FOOD, "peace out", 33.33,
				"you.jpg");
		try {
			company1.createCoupon(Coupon1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Coupon Coupon2 = new Coupon(777, "sun3", new java.sql.Date(new Date().getTime()),
				new java.sql.Date(new Date().getTime() + (13 * 86400000)), 60, CouponType.HEALTH, "peace out", 33.33,
				"you.jpg");
		try {
			company1.createCoupon(Coupon2);
		} catch (Exception e) {
			e.printStackTrace();
		}
		Coupon Coupon3 = new Coupon(777, "sun4", new java.sql.Date(new Date().getTime()),
				new java.sql.Date(new Date().getTime() + (20 * 86400000)), 60, CouponType.TRAVELLING, "peace out",
				33.33, "you.jpg");
		try {
			company1.createCoupon(Coupon3);
		} catch (Exception e) {
			e.printStackTrace();
		}
		DailyThread.ShutDown();
	}

}
