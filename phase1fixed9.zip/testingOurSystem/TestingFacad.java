package testingOurSystem;

import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Date;
import java.util.Enumeration;

import Data_Base.DropAllTables;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import Facade.AdminFacade;
import Facade.ClientType;
import Facade.CompanyFacade;
import Facade.CouponSystem;
import Facade.CustomerFacade;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class TestingFacad {

	public static void main(String[] args) {
		Enumeration<Driver> en = DriverManager.getDrivers();

		// print drivers
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement().getClass().getName());
		}
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		try {
			Class.forName(driverName);
			System.out.println(driverName + " loaded successfuly");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			DropAllTables.dropTables();
			System.out.println("all the tabels have been droped");
			Data_Base.create_tables3.main(null);
			System.out.println("all the tabels have been created");
			CouponSystem Csys = CouponSystem.getInstance();
			AdminFacade admin = (AdminFacade) Csys.login("admin", "1234", ClientType.Admin);
			System.out.println(admin);
			admin.createCompany(new Company(100L, "Pink My Ride", "1234", "admin@pink.com"));
			CompanyFacade company = (CompanyFacade) Csys.login("Pink My Ride", "1234", ClientType.Company); // company.g
			System.out.println(company);
			// long id, String title, Date startDate, Date endDate, int amount,
			// CouponType type, String message,double price, String image) {
			Coupon coupon = new Coupon(1L, "all free", new Date(), new Date(new Date().getTime() + 100000), 50,
					CouponType.FOOD, "no more hungery people", 0.00, "no image");
			company.createCoupon(coupon);
			System.out.println("the new coupon" + company);
			admin.createCustomer(new Customer(0L, "shahaf", "qGDGJKASDFGAKJDGFJADSDFSSXCCG1"));
			CustomerFacade customer = (CustomerFacade) Csys.login("shahaf", "qGDGJKASDFGAKJDGFJADSDFSSXCCG1",
					ClientType.Customer);
			customer.purchaseCoupon(coupon);
			System.out.println(customer);
			System.out.println(company);
			System.out.println(coupon);
			System.out.println("show all coupon" + company.getAllCoupon());
		} catch (ConnectionPoolException | DAOException | FacadeException exception) {
			System.out.println("caught exception");
		}
	}
}
