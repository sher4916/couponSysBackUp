package testingOurSystem;

import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Date;
import java.util.Enumeration;

import Data_Base.DropAllTables;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import Facade.AdminFacade;
import Facade.ClientType;
import Facade.CompanyFacade;
import Facade.CouponSystem;
import Facade.CustomerFacade;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class testingFacad2 {

	public static void main(String[] args) {
		Enumeration<Driver> en = DriverManager.getDrivers();

		// print drivers
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement().getClass().getName());
		}
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		try {
			Class.forName(driverName);
			System.out.println(driverName + " loaded successfuly");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		try {
			DropAllTables.dropTables();
			System.out.println("all the tabels have been droped");
			Data_Base.create_tables3.main(null);
			System.out.println("all the tabels have been created");
			CouponSystem Csys = CouponSystem.getInstance();
			AdminFacade admin = (AdminFacade) Csys.login("admin", "1234", ClientType.Admin);
			System.out.println(admin);
			admin.createCompany(new Company(100L, "noty", "1234", "admin@pink.com"));
			CompanyFacade company = (CompanyFacade) Csys.login("noty", "1234", ClientType.Company); // company.g
			System.out.println(company);
			Coupon coupon = new Coupon(1L, "all free", new Date(), new Date(new Date().getTime() + 10000000), 50,
					CouponType.FOOD, "no more hungery people", 0.00, "no image");
			company.createCoupon(coupon);
			System.out.println(company);
			System.out.println(company.getAllCoupon());
			admin.createCustomer(new Customer(132, "shahaf", "123"));
			CustomerFacade customer = (CustomerFacade) Csys.login("shahaf", "123", ClientType.Customer);
			System.out.println(customer);
			System.out.println("-----------------------------------");
			customer.purchaseCoupon(coupon);
			System.out.println(company);
			System.out.println(customer);
			company.removeCoupon(coupon);
			System.out.println(company);
			System.out.println(customer);
		} catch (ConnectionPoolException | DAOException | FacadeException exception) {
			System.out.println("caught exception");
		}
	}
}
