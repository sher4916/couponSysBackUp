package testingOurSystem;

import java.sql.Driver;
import java.sql.DriverManager;
import java.util.Date;
import java.util.Enumeration;

import DBDAO.CompanyDBDAO;
import DBDAO.CouponDBDAO;
import Data_Base.Connection_Pool;
import Data_Base.DropAllTables;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import Facade.AdminFacade;
import Facade.ClientType;
import Facade.CompanyFacade;
import Facade.CouponSystem;
import Facade.CustomerFacade;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class TestMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Enumeration<Driver> en = DriverManager.getDrivers();

		// print drivers
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement().getClass().getName());
		}
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		try {
			Class.forName(driverName);
			System.out.println(driverName + " loaded successfuly");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		Facade.DailyThread DailyThread;
		try {
			DropAllTables.dropTables();
			System.out.println("all the tabels have been droped");
			Data_Base.create_tables3.main(null);
			System.out.println("all the tabels have been created");
			try {
				// Connection_Pool.getInstance().CreateDBandConnections("jdbc:derby://localhost:1527/coupondb",
				// 10);
				Connection_Pool.getInstance().getConnection();
			} catch (ConnectionPoolException e1) {
				ConnectionPoolException cantConnect = new ConnectionPoolException(
						"Unable to connect to the database, please check your url path");
				throw cantConnect;
			}
			// Open the Coupon System
			CouponSystem Csys = CouponSystem.getInstance();
			// prepare the Daily Thread to run
			DailyThread = new Facade.DailyThread("admin", "1234");
			// login as admin
			AdminFacade admin = (AdminFacade) Csys.login("admin", "1234", ClientType.Admin);
			// creating a company
			admin.createCompany(new Company("shahaf", "1234", "shahaf@gmail.com"));
			// test roni
			Company company5 = new Company("shahaf5", "1234", "shahaf@gmail.com");
			admin.createCompany(company5);
			CompanyFacade company1 = (CompanyFacade) Csys.login("shahaf", "1234", ClientType.Company);
			// printing company java beans
			System.out.println(company1);
			// forcing add of a coupon which has an expired date to the data
			// base
			Coupon Coupon = new Coupon(777, "all free", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() - 86400000), 60, CouponType.SPORTS, "peace out", 33.33,
					"you.jpg");
			try {
				company1.createCoupon(Coupon);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(Coupon);
			CompanyDBDAO companyDBDAO = new CompanyDBDAO();
			CouponDBDAO couponDBDAO = new CouponDBDAO();
			couponDBDAO.createCoupon(Coupon);
			Coupon.setId(couponDBDAO.getCouponByTitle(Coupon.getTitle()).getId());
			Company tempc = company1.getCompanyDetails();
			companyDBDAO.CreateCoupon(Coupon, tempc);
			companyDBDAO.updateCompany(tempc);
			System.out.println(company1);
			// activating the daily thread to delete this expired coupon
			DailyThread.start();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(company1);
			// creating a couple of companies
			admin.createCompany(new Company("shahaf2", "1234", "shahaf@gmail.com"));
			CompanyFacade company2 = (CompanyFacade) Csys.login("shahaf2", "1234", ClientType.Company);
			System.out.println(company2);
			admin.createCompany(new Company("shahaf3", "1234", "shahaf@gmail.com"));
			CompanyFacade company3 = (CompanyFacade) Csys.login("shahaf3", "1234", ClientType.Company);
			System.out.println(company3);
			System.out.println(admin.getAllCompanies());
			// creating several coupons
			Coupon Coupon2 = new Coupon(777, "all free2", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() + (3 * 86400000)), 60, CouponType.SPORTS, "peace out", 33.33,
					"you.jpg");
			// company1 creates the coupon2
			company1.createCoupon(Coupon2);
			Coupon Coupon3 = new Coupon(777, "all free928208302183230", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() + (3 * 86400000)), 60, CouponType.CAMPING, "peace out",
					338.33, "you.jpg");
			// company2 creates the coupon3
			company2.createCoupon(Coupon3);
			Coupon Coupon4 = new Coupon(777, "all free92820802183230", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() + (3 * 86400000)), 60, CouponType.ELECTRICITY, "peace out",
					343.33, "you.jpg");
			company2.createCoupon(Coupon4);

			Coupon Coupon5 = new Coupon(777, "all free5", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() + (3 * 86400000)), 60, CouponType.SPORTS, "peace out5",
					53.33, "you.jpg");
			// company1 creates the coupon2
			company1.createCoupon(Coupon5);

			Coupon Coupon6 = new Coupon(777, "all free6", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() + (3 * 86400000)), 60, CouponType.SPORTS, "peace out6",
					63.33, "you.jpg");
			// company1 creates the coupon2
			company1.createCoupon(Coupon6);

			Coupon Coupon7 = new Coupon(777, "all free7", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() + (3 * 86400000)), 60, CouponType.SPORTS, "peace out7",
					73.33, "you.jpg");
			// company1 creates the coupon2
			company1.createCoupon(Coupon7);
			System.out.println(admin.getAllCoupons());
			admin.createCustomer(new Customer("shahaf", "1111"));
			// Customer1 login
			CustomerFacade customer1 = (CustomerFacade) Csys.login("shahaf", "1111", ClientType.Customer);
			System.out.println(customer1);
			// customer1 trying to buy coupon that the daily thread deleted
			// earlier and will get a facade exception
			try {
				customer1.purchaseCoupon(Coupon);
			} catch (Exception e) {
				e.printStackTrace();
			}
			customer1.purchaseCoupon(Coupon4);
			System.out.println("customer1 purchase coupon4");
			customer1.purchaseCoupon(Coupon3);
			System.out.println("customer1 purchase Coupon3");
			customer1.purchaseCoupon(Coupon2);
			System.out.println("customer1 purchase Coupon2");
			// now check which coupon are available for customer 1 to purchase
			customer1.getAvialableCouponsForPurchase();
			System.out.println("above will be all Avialable Coupons For Purchase");
			System.out.println(customer1.getAllPurchasedCouponsByPrice(130.0));
			company1.removeCoupon(Coupon2);
			System.out.println(customer1.getAllPurchasedCouponsByPrice(130.0));

			System.out.println("company befor update: " + company1);
			// updating company1
			Company company = company1.getCompanyDetails();
			company.setEmail("helloworld@gmail.com");
			admin.updateCompany(company);
			System.out.println("company after update: " + company1);
			// trying to change company name, will throw company does not exists
			// in the database exception
			try {
				company.setCompName("illigal");
				admin.updateCompany(company);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(company1);
			// forcing add of a coupon which has an expired date to the data
			// base
			Coupon CouponEx = new Coupon(777, "all free", new java.sql.Date(new Date().getTime()),
					new java.sql.Date(new Date().getTime() - 86400000), 60, CouponType.SPORTS, "peace out", 33.33,
					"you.jpg");
			try {
				company1.createCoupon(CouponEx);
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(CouponEx);
			couponDBDAO.createCoupon(CouponEx);
			CouponEx.setId(couponDBDAO.getCouponByTitle(CouponEx.getTitle()).getId());
			tempc = company1.getCompanyDetails();
			companyDBDAO.CreateCoupon(CouponEx, tempc);
			companyDBDAO.updateCompany(tempc);
			System.out.println(company1);

			System.out.println(customer1);
			System.out.println(admin.getAllCoupons());
			// here customer 1 tries to purchase an expired coupon and not
			// Succeed, this coupon will be deleted from the data base
			try {

				customer1.purchaseCoupon(CouponEx);
			} catch (Exception e) {
				e.printStackTrace();
			}

			System.out.println(customer1);
			System.out.println(company1);

			System.out.println(admin.getAllCoupons());

			// tries to create a customer with the same name

			System.out.println(admin.getAllCustomer());
			try {
				admin.createCustomer(customer1.ThisCustomer());
			} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println(admin.getAllCustomer());

			// create multiple customers
			admin.createCustomer(new Customer("roni", "217351273124"));
			CustomerFacade customer2 = (CustomerFacade) Csys.login("roni", "217351273124", ClientType.Customer);
			System.out.println(admin.getAllCustomer());
			// admin remove company
			admin.removeCompany(company5);
			System.out.println("company 5 removed");
			DailyThread.ShutDown();
		} catch (ConnectionPoolException | DAOException | FacadeException e1) {
			// TODO Auto-generated catch block

			e1.printStackTrace();

		}

	}
}
