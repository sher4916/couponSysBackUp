package Data_Base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import Exceptions.ConnectionPoolException;

public class Connection_Pool {
	private static Connection_Pool INSTANCE;
	private Set<Connection> openedConnections;
	private Set<Connection> CloseConnections;
	String url = "jdbc:derby://localhost:1527/coupon;create=true";
	private boolean isClosed;
	String driverName;

	private Connection_Pool() throws ConnectionPoolException {
		driverName = "org.apache.derby.jdbc.ClientDriver";
		try {
			Class.forName(driverName);
			openedConnections = new HashSet<>();
			CloseConnections = new HashSet<>();
			isClosed = false;
		} catch (ClassNotFoundException e) {
			throw new ConnectionPoolException("driver couldnt load");
		}

	}

	/**
	 * this method Creates the DB(if not already created) and 2 sets of
	 * Connections, for closed and open connections, it also gives a limited
	 * number of connections available
	 * 
	 * @param url
	 *            is the DB location
	 * @param numOfConn
	 *            is the limited number of connections available
	 * @throws ConnectionPoolException
	 *             - Unable to connect to the database, please check your url
	 *             path
	 */
	public void CreateDBandConnections(String url, int numOfConn) throws ConnectionPoolException {

		Connection conn;
		url = url + ";create = true";
		try {
			for (int i = 0; i < numOfConn; i++) {
				conn = DriverManager.getConnection(url);
				openedConnections.add(conn);
				CloseConnections.add(conn);

			}
		} catch (SQLException e) {
			ConnectionPoolException cantConnect = new ConnectionPoolException(
					"Unable to connect to the database, please check your url path");
			throw cantConnect;
		}

	}

	/**
	 * this method gets Object of connection when there is a free opened
	 * connection in the 'openedConnections' set, when caught connection it will
	 * remove it from the set and will notify all Object waiting on this thread
	 * 
	 * @return Object of connection when there is a free opened connection in
	 *         the 'openedConnections' set
	 * @throws ConnectionPoolException
	 *             - Unable to connect to the database, please check your url
	 *             path
	 */
	public Connection getConnection() throws ConnectionPoolException {

		Connection conn = null;
		url = "jdbc:derby://localhost:1527/coupondb;create = true";
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			// for (int i = 0; i < 10; i++) {
			conn = DriverManager.getConnection(url);
			// openedConnections.add(conn);
			// CloseConnections.add(conn);

			// }
		} catch (SQLException | ClassNotFoundException e) {
			ConnectionPoolException cantConnect = new ConnectionPoolException(
					"Unable to connect to the database, please check your url path");
			throw cantConnect;
		}
		return conn;
	}

	public Connection getShahafConnection() throws ConnectionPoolException {
		if (isClosed) {
			return null;
		}
		boolean isCaughtConn = false;
		Connection CaughtConn = null;
		while (!isCaughtConn) {
			synchronized (openedConnections) {
				if (!openedConnections.isEmpty()) {

					Iterator<Connection> openConnectionsItrator = openedConnections.iterator();
					if (openConnectionsItrator.hasNext()) {
						CaughtConn = openConnectionsItrator.next();
						openConnectionsItrator.remove();
						openedConnections.notifyAll();
						isCaughtConn = true;

					}

				} else {
					try {
						openedConnections.wait();
					} catch (InterruptedException e) {
						ConnectionPoolException interapt = new ConnectionPoolException(
								"Connection Pool has been interrupted");
						throw interapt;
					}
				}
			}
		}
		return CaughtConn;
	}

	/**
	 * this method uses a specific connection and once its done with it, it
	 * releases the connection and add this spare connection to the opened
	 * connection set and notify all waiting on the thread
	 * 
	 * @param conn
	 *            is the connection to release
	 */
	public void releaseConn(Connection conn) {

		openedConnections.add(conn);
		synchronized (openedConnections) {
			openedConnections.notifyAll();

		}

	}

	/**
	 * this method uses the CreateDBandConnections method and does it exactly
	 * the same. Creates the DB(if not already created) and 2 sets of
	 * Connections, for closed and open connections, it also gives a limited
	 * number of connections available
	 * 
	 * @param url
	 *            is the DB location
	 * @param numOfConn
	 *            is the limited number of connections available
	 * @throws ConnectionPoolException
	 *             - Unable to connect to the database, please check your url
	 *             path
	 */
	public void CreateConnections(String url, int numOfConn) throws ConnectionPoolException {
		this.CreateDBandConnections(url, numOfConn);
	}

	/**
	 * this method will use the class Connection_Pool to return the single
	 * instance of the object which is the reference
	 * 
	 * @return single instance of the object which is the reference for the
	 *         connection_Pool
	 * @throws ConnectionPoolException
	 */
	public static Connection_Pool getInstance() throws ConnectionPoolException {
		if (INSTANCE == null) {
			INSTANCE = new Connection_Pool();
		}
		return INSTANCE;
	}

	/**
	 * this method will close all connections associated with this class
	 * instance
	 * 
	 * @throws ConnectionPoolException
	 *             - Unable to connect to the database, please check your url
	 *             path
	 */
	public void closeAllConnections() throws ConnectionPoolException {
		isClosed = true;
		while (openedConnections.size() < CloseConnections.size()) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				ConnectionPoolException interapt = new ConnectionPoolException("Connection Pool has been interupted");
				throw interapt;
			}
		}
		Iterator<Connection> iterator = CloseConnections.iterator();
		while (iterator.hasNext()) {
			Connection connection = (Connection) iterator.next();
			try {
				connection.close();
			} catch (SQLException e) {
				ConnectionPoolException connectionError = new ConnectionPoolException(
						"Communication problem with the database");
				throw connectionError;
			}

		}
	}

}
