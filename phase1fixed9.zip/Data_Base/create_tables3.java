package Data_Base;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Enumeration;

import Exceptions.ConnectionPoolException;

/**
 * this create table class will run under the main method, establish connection
 * to the Data Base, prepare statements and create all tables in DB
 *
 */
public class create_tables3 {
	/**
	 * this main method will create all tables in DB
	 * 
	 * @param args
	 * @throws ConnectionPoolException
	 *             - Unable to connect to the database, please check your url
	 *             path
	 */
	public static void main(String[] args) throws ConnectionPoolException {
		Enumeration<Driver> en = DriverManager.getDrivers();

		// print drivers
		while (en.hasMoreElements()) {
			System.out.println(en.nextElement().getClass().getName());
		}
		String driverName = "org.apache.derby.jdbc.ClientDriver";

		try {
			Class.forName(driverName);
			System.out.println(driverName + " loaded successfuly");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		/**
		 * this static method of drop all tables is made in order for the code
		 * to run every time so first, we'll delete all tables and then create
		 * them. in the real world we'll not use such method performed on DB.
		 * 
		 */

		// TODO DropAllTables.dropTables();

		String url = "jdbc:derby://localhost:1527/coupondb;create=true";
		String createCompany = "CREATE TABLE Company( ID  BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),COMP_NAME VARCHAR(50) NOT NULL UNIQUE, password VARCHAR(50) ,EMAIL VARCHAR(50),PRIMARY KEY(ID))";
		String createCustomer = "CREATE TABLE Customer (ID BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),CUST_NAME VARCHAR(50) NOT NULL UNIQUE,PASSWORD VARCHAR(50),PRIMARY KEY(ID))";
		String createCoupon = "CREATE TABLE Coupon (ID BIGINT GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1) ,TITLE VARCHAR(100) NOT NULL UNIQUE, START_DATE DATE, END_DATE DATE,AMOUNT INT, TYPE VARCHAR(50),MESSAGE VARCHAR(150),PRICE DOUBLE, IMAGE VARCHAR(250),PRIMARY KEY(ID))";
		String createCustomerCoupon = "CREATE TABLE Customer_Coupon(CUST_ID  BIGINT ,COUPON_ID INT,PRIMARY KEY( CUST_ID ,COUPON_ID))";
		String createCompanyCoupon = "CREATE TABLE Company_Coupon(COMP_ID BIGINT,COUPON_ID INT,PRIMARY KEY( COMP_ID ,COUPON_ID))";

		try {
			Connection_Pool.getInstance().CreateDBandConnections(url, 10);
		} catch (ConnectionPoolException e1) {
			ConnectionPoolException cantConnect = new ConnectionPoolException(
					"Unable to connect to the database, please check your url path");
			throw cantConnect;
		}
		try (Connection con = Connection_Pool.getInstance().getConnection(); Statement stmt = con.createStatement();) {
			stmt.executeUpdate(createCompany);
			stmt.executeUpdate(createCustomer);
			stmt.executeUpdate(createCoupon);
			stmt.executeUpdate(createCustomerCoupon);
			stmt.executeUpdate(createCompanyCoupon);
			System.out.println("all tables created");

		} catch (SQLException | ConnectionPoolException e) {
			ConnectionPoolException cantConnect = new ConnectionPoolException(
					"Unable to connect to the database, please check your url path");
			throw cantConnect;
		}

	}
}
