package Data_Base;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import Exceptions.ConnectionPoolException;

public class DropAllTables {
	private static String url = "jdbc:derby://localhost:1527/coupondb";
	private static String drop1 = "DROP TABLE Company";
	private static String drop2 = "DROP TABLE Customer";
	private static String drop3 = "DROP TABLE Coupon";
	private static String drop4 = "DROP TABLE Customer_Coupon";
	private static String drop5 = "DROP TABLE Company_Coupon";

	/**
	 * this main method will delete all tables in DB and re-create them
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		dropTables();
		try {
			create_tables3.main(args);
		} catch (ConnectionPoolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * this method deletes all tables in DB
	 */
	public static void dropTables() {
		try (Connection con = DriverManager.getConnection(getUrl()); Statement stmt = con.createStatement();) {
			stmt.executeUpdate(getDrop1());
			stmt.executeUpdate(getDrop2());
			stmt.executeUpdate(getDrop3());
			stmt.executeUpdate(getDrop4());
			stmt.executeUpdate(getDrop5());
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("all tables dropped");
	}

	public static String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		DropAllTables.url = url;
	}

	public static String getDrop1() {
		return drop1;
	}

	public void setDrop1(String drop1) {
		DropAllTables.drop1 = drop1;
	}

	public static String getDrop2() {
		return drop2;
	}

	public void setDrop2(String drop2) {
		DropAllTables.drop2 = drop2;
	}

	public static String getDrop3() {
		return drop3;
	}

	public void setDrop3(String drop3) {
		DropAllTables.drop3 = drop3;
	}

	public static String getDrop4() {
		return drop4;
	}

	public void setDrop4(String drop4) {
		DropAllTables.drop4 = drop4;
	}

	public static String getDrop5() {
		return drop5;
	}

	public void setDrop5(String drop5) {
		DropAllTables.drop5 = drop5;
	}

}
