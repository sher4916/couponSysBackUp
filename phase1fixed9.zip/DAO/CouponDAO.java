package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collection;

import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public interface CouponDAO {

	/**
	 * this method will create an Object of coupon and insert 1 row to Coupon
	 * table in DB
	 * 
	 * @param Coupon
	 *            is the Object Coupon to create in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to create new coupon in DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void createCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException;

	/**
	 * this method will delete a specific coupon in Coupon table in DB, it will
	 * also delete this coupon from Company_Coupon table and from
	 * Customer_Coupon table
	 * 
	 * @param Coupon
	 *            is the Object Coupon that will be deleted from
	 *            Coupon,Company_Coupon and Customer_Coupon tables
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to remove coupon from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void removeCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException;

	/**
	 * this method will update a specific coupon in Coupon table in DB
	 * 
	 * @param Coupon
	 *            is the Coupon Object /row that will be updated in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to update coupon in DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	void updateCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the specific Coupon details that has the this Coupon
	 * ID
	 * 
	 * @param id
	 *            is the Coupon id to provide
	 * @return the Coupon details/Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Coupon getCoupon(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns all the Coupons that exist in DB
	 * 
	 * @return all the rows in DB from Coupon table
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get all coupons from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Collection<Coupon> getAllCoupons() throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons of that given Coupon
	 * Type
	 * 
	 * @param couponType
	 *            is the Type of Coupon you wish to get
	 * @return a Collection of all the coupons of that given Coupon Type
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getCouponByType(CouponType couponType) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons which the specific,
	 * by id, customer purchased
	 * 
	 * @param id
	 *            is the customer id that owns the coupons
	 * @return a Collection of all the coupons which the specific customer owns
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getAllCouponsOfCustID(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons that belong to the
	 * given Company by its ID
	 * 
	 * @param id
	 *            is the Company ID to get
	 * @return a Collection of all the coupons that belong to the given Company
	 *         ID
	 * @throws ConnectionPoolException
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getAllCouponsOfCompenyID(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons that belong to the
	 * given Customer Object
	 * 
	 * @param customer
	 *            is the Customer Object
	 * @return a Collection of all the coupons that belong to the given Customer
	 *         Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getAllCouponsOfCustID(Customer customer) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons that belong to the
	 * given Company Object
	 * 
	 * @param company
	 *            is the Company Object
	 * @return a Collection of all the coupons that belong to the given Company
	 *         Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             Unable to get coupon from DB - you might have a connection or
	 *             Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getAllCouponsOfCompenyID(Company company) throws ConnectionPoolException, DAOException;

	/**
	 * this method is using the ResultSet that comes from the DB and inserting
	 * in into the Coupon Object
	 * 
	 * @param coupon
	 *            is the Coupon Object to fill
	 * @param rs
	 *            is the ResultSet that comes with info from the DB
	 * @throws SQLException
	 *             - if the columnIndex is not valid; if a database access error
	 *             occurs or this method is called on a closed result set
	 */
	void FillCoupon(Coupon coupon, ResultSet rs) throws SQLException;

	/**
	 * this method is using the PreparedStatement to retrieve data from the
	 * Coupon Object and insert it into the DB Table
	 * 
	 * @param Coupon
	 *            is the Coupon Object to get info from
	 * @param pstmt
	 *            is the PreparedStatement to insert to DB
	 * @throws SQLException
	 *             - if parameterIndex does not correspond to a parameter marker
	 *             in the SQL statement; if a database access error occurs or
	 *             this method is called on a closed PreparedStatement
	 */
	void FillPstmtCoupon(Coupon Coupon, PreparedStatement pstmt) throws SQLException;

	/**
	 * this method returns a Collection of all the Customers that owns the given
	 * Coupon Object
	 * 
	 * @param coupon
	 *            is the Coupon Object
	 * @return a Collection of all the Customers that owns the given Coupon
	 *         Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get customers from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Collection<Customer> getAllCustomersPerCouponId(Coupon coupon) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons of the given Coupon
	 * Type and belong to the given Customer id
	 * 
	 * @param id
	 *            is the Customer id that owns the Coupons
	 * @param couponType
	 *            is the Type of Coupon which comes from an enum class
	 *            CouponType in JavaBeans
	 * @return a Collection of all the coupons of the given Coupon Type and
	 *         belong to the given Customer id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupons from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getAllCouponsPerCustIDByType(long id, CouponType couponType)
			throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the coupons that their cost is up
	 * to the given price and belong to the given Customer id
	 * 
	 * @param price
	 *            is the max price to get Coupons
	 * @param id
	 *            is the Customer id that owns the Coupons
	 * @return a Collection of all the coupons that their cost is up to the
	 *         given price and belong to the given Customer id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get customers from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Collection<Coupon> getAllCouponsByPrice(Double price)
			throws ConnectionPoolException, DAOException;

	/**
	 * this method returns a Collection of all the Customers that owns the given
	 * Coupon id
	 * 
	 * @param id
	 *            is the Coupon id
	 * @return a Collection of all the Customers that owns the given Coupon id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             Unable to get customers from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Customer> getAllCustomersPerCouponId(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method check of the given Coupon Object belongs to the given Company
	 * id
	 * 
	 * @param Coupon
	 *            is Coupon Object
	 * @param id
	 *            is the Company id
	 * @return true if the given Coupon Object belongs to the given Company id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupons from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	boolean CouponIsBelongToCompany(Coupon Coupon, long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method check of the given Coupon Object belongs to the given
	 * Customer id
	 * 
	 * @param Coupon
	 *            is Coupon Object
	 * @param id
	 *            is the Customer id
	 * @return true if the given Coupon Object belongs to the given Customer id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupons from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	boolean CouponIsBelongToCustomer(Coupon Coupon, long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the Object Coupon that has the given Title
	 * 
	 * @param Title
	 *            is the Coupon Title
	 * @return the Object Coupon that has the given Title
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupons from DB-you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Coupon getCouponByTitle(String Title) throws ConnectionPoolException, DAOException;
}
