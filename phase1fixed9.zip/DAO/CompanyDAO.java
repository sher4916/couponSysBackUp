package DAO;

import java.util.Collection;

import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import java_beans.Company;
import java_beans.Coupon;

public interface CompanyDAO {

	/**
	 * this method will create an Object of company and insert 1 row to Company
	 * table in DB
	 * 
	 * @param company
	 *            is the Object company to create in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -Unable to create new company in DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void createCompany(Company company) throws ConnectionPoolException, DAOException;

	/**
	 * this method will delete a specific Company in Company table in DB
	 * 
	 * @param company
	 *            is the Object company that will be deleted from Company table
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to remove company from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void removeCompany(Company company) throws ConnectionPoolException, DAOException;

	/**
	 * this method will update a specific company in Company table in DB
	 * 
	 * @param company
	 *            is the Company Object /row that will be updated in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to update company in DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void updateCompany(Company company) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the specific Company details that has the this
	 * company ID
	 * 
	 * @param id
	 *            is the Company id to provide
	 * @return the Company details/Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get company from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Company getCompany(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns all the companies that exist in DB
	 * 
	 * @return all the rows in DB from company table
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get All Companies from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Collection<Company> getAllCompanies() throws ConnectionPoolException, DAOException;

	/**
	 * this method checks in DB whether the given params exist in Company table
	 * 
	 * @param compName
	 *            is the company name
	 * @param password
	 *            is the password for this specific company
	 * @return true if given params exist in Company table and false when params
	 *         don't exist in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to confirm login credentials in DB-you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	boolean login(String compName, String password) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the Collection of coupons a specific company (by id)
	 * have
	 * 
	 * @param id
	 *            is the company id
	 * @return Collection of coupons for a specific company
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getCouponsPerCompany(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method creates a coupon for a company, the coupon is associated with
	 * the company and can be sold only by this company
	 * 
	 * @param Coupon
	 *            is the coupon to create
	 * @param Comp
	 *            is the company that can sell the coupon
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to create coupon in DB-you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	void CreateCoupon(Coupon Coupon, Company Comp) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the Object company from the DB by searching it with
	 * the company name
	 * 
	 * @param name
	 *            is the name of company to search in DB
	 * @return the Object company found by company name
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get company from DB-you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Company getCompenyByName(String name) throws ConnectionPoolException, DAOException;
}
