/**
 * DAO is the interface collection of the DAO layer of the application. This
 * layer performs the mySQL oparations of the application, which are the
 * communication methods of the application with the database.</br>
 * No communication with database is made out of this layer, for the safety of
 * the code. </br>
 * The layer is a channel between the database and the {@link Facades} layer.
 */
package DAO;