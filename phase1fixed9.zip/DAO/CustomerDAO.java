package DAO;

import java.util.Collection;

import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import java_beans.Coupon;
import java_beans.Customer;

public interface CustomerDAO {
	/**
	 * this method will create an Object of Customer and insert 1 row to
	 * Customer table in DB
	 * 
	 * @param Customer
	 *            is the Object Customer to create in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to create new customer in DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void createCustomer(Customer Customer) throws ConnectionPoolException, DAOException;

	/**
	 * this method will delete a specific Customer in Customer table in DB
	 * 
	 * @param Customer
	 *            is the Object Customer that will be deleted from Customer
	 *            table
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to remove customer from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void removeCustomer(Customer Customer) throws ConnectionPoolException, DAOException;

	/**
	 * this method will update a specific Customer in Customer table in DB
	 * 
	 * @param Customer
	 *            is the Customer Object /row that will be updated in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to update customer in DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	void updateCustomer(Customer Customer) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the specific Customer details that has the this
	 * Customer ID
	 * 
	 * @param id
	 *            is the Customer id to provide
	 * @return the Customer details/Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get customer from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Customer getCustomer(long id) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns all the Customers that exist in DB
	 * 
	 * @return all the rows in DB from Customer table
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get all customers from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Collection<Customer> getAllCustomers() throws ConnectionPoolException, DAOException;

	Collection<Coupon> getAvialableCouponsForPurchase(Customer customer) throws ConnectionPoolException, DAOException;

	/**
	 * this method checks in DB whether the given params exist in Customer table
	 * 
	 * @param custName
	 *            is the Customer name
	 * @param password
	 *            is the password for this specific Customer
	 * @return true if given params exist in Customer table and false when
	 *         params don't exist in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to confirm login credentials in DB - you might have
	 *             a connection or Query problem, please check your url path and
	 *             your Query
	 */
	boolean login(String custName, String password) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the Collection of coupons a specific Customer (by id)
	 * have
	 * 
	 * @param cust_id
	 *            is the Customer id
	 * @return Collection of coupons for a specific Customer
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get coupon from DB - you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	Collection<Coupon> getCouponsPerCustomer(long cust_id) throws ConnectionPoolException, DAOException;

	/**
	 * this method will add a new row to Customer_Coupon table in DB that will
	 * indicate that the specific coupon now belongs to a specific customer
	 * 
	 * @param Coupon
	 *            is the coupon that the specific customer purchased
	 * @param cust
	 *            is the Customer that performs the purchase
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to purchase coupon in DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 * @throws DAOException
	 *             - Unable to purchase coupon in DB - There are not enough
	 *             amount of coupons
	 */
	void purchaseCoupon(Coupon Coupon, Customer cust) throws ConnectionPoolException, DAOException;

	/**
	 * this method will delete a specific Coupon that belongs to a specific
	 * Customer from Customer_Coupon table in DB
	 * 
	 * @param Coupon
	 *            is the Coupon that will be deleted from Customer_Coupon table
	 * @param Customer
	 *            is the Customer that the specific Coupon belongs to
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to remove coupon in DB-you might have a connection
	 *             or Query problem, please check your url path and your Query
	 */
	void removeCustomerCoupon(Coupon Coupon, Customer Customer) throws ConnectionPoolException, DAOException;

	/**
	 * this method returns the Object Customer from the DB by searching it with
	 * the Customer name
	 * 
	 * @param name
	 *            is the name of Customer to search in DB
	 * @return the Object Customer found by Customer name
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             - Unable to get customer from DB - you might have a
	 *             connection or Query problem, please check your url path and
	 *             your Query
	 */
	Customer getCustomerByName(String name) throws ConnectionPoolException, DAOException;

}
