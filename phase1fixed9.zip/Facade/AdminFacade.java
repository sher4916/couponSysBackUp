package Facade;

import java.util.Collection;

import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.Customer;

public class AdminFacade extends Client implements CouponClientFacade {

	/**
	 * this method create a new company, it will first check that company with
	 * the same name doesn't already exist,only logged in Admin will be able to
	 * use this method
	 * 
	 * @param Company
	 *            is the Company Object to create
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - one of your Company parameters is null-please check it
	 * @throws FacadeException
	 *             - your Company name length is invalid-name must be 3-50
	 *             characters
	 * @throws FacadeException
	 *             - your Company email is not valid
	 * @throws FacadeException
	 *             - throw exception invalid password
	 * @throws FacadeException
	 *             - unable to create Company- Company name already exist in DB
	 * @throws FacadeException
	 *             - you need to login as admin in order to create new company
	 */
	public void createCompany(Company Company) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			if (super.companyDBDAO.getCompenyByName(Company.getCompName()) == null) {
				if (super.isValidCompany(Company)) {
					super.companyDBDAO.createCompany(Company);
					Company.setId(super.companyDBDAO.getCompenyByName(Company.getCompName()).getId());
				}

			} else {
				FacadeException facadeException = new FacadeException(
						"unable to create Company- Company name already exist in DB");
				throw facadeException;
			}

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to create new company");
			throw facadeException;
		}
	}

	/**
	 * this method removes/delete company, it will first check that company with
	 * the same name exist and will delete it,only logged in Admin will be able
	 * to use this method
	 * 
	 * @param Company
	 *            is the Company Object to remove
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - Unable to remove company, a company with that name or ID
	 *             does not exist
	 * @throws FacadeException
	 *             - you need to login as admin in order to remove company
	 * @throws FacadeException
	 *             - remove failed- Company does not exist in DB
	 */
	public void removeCompany(Company Company) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			if (Company.getCompName() != null) {

				super.companyDBDAO.removeCompany(Company);
			} else {
				FacadeException facadeException = new FacadeException(
						"Unable to remove company, a company with that name or ID does not exist");
				throw facadeException;
			}
		} else

		{
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to remove company");
			throw facadeException;
		}
	}

	/**
	 * this method updates company, it will first check that company with the
	 * same name exist and then update it,only logged in Admin will be able to
	 * use this method
	 * 
	 * @param Company
	 *            is the Company Object to update
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - one of your Company parameters is null-please check it
	 * @throws FacadeException
	 *             - your Company name length is invalid-name must be 3-50
	 *             characters
	 * @throws FacadeException
	 *             - your Company email is not valid
	 * @throws FacadeException
	 *             - throw exception invalid password
	 * @throws FacadeException
	 *             - you need to login as admin in order to update company
	 * @throws FacadeException
	 *             - update failed- Company does not exist in DB
	 */
	public void updateCompany(Company Company) throws ConnectionPoolException, DAOException, FacadeException {

		if (super.IsloginAs(ClientType.Admin)) {
			if (super.isValidCompany(Company)) {
				Company last = super.companyDBDAO.getCompenyByName(Company.getCompName());
				if (last == null) {
					FacadeException facadeException = new FacadeException(
							"update failed- Company does not exist in DB");
					throw facadeException;
				}
				if (Company.getId() == last.getId() && Company.getCompName().equals(last.getCompName())) {
					super.companyDBDAO.updateCompany(Company);
				} else {
					FacadeException facadeException = new FacadeException(
							"update failed- Company does not exist in DB");
					throw facadeException;
				}
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to update company");
			throw facadeException;
		}
	}

	/**
	 * this method get java beans company object associated with the given id,
	 * only logged in Admin will be able to use this method
	 * 
	 * @param id
	 *            is the Company id
	 * @return java beans company object associated with the given id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin
	 * @throws FacadeException
	 */
	public Company getCompany(long id) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			return super.ThisCompany(id);
		} else {
			FacadeException facadeException = new FacadeException("you need to login as admin in order to get company");
			throw facadeException;
		}
	}

	/**
	 * this method get java beans Companies Collection, only logged in Admin
	 * will be able to use this method
	 * 
	 * @return java beans Companies Collection
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as admin in order to get All Companie
	 */
	public Collection<Company> getAllCompanies() throws ConnectionPoolException, DAOException, FacadeException

	{
		if (super.IsloginAs(ClientType.Admin)) {
			return super.companyDBDAO.getAllCompanies();
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to  get All Companies");
			throw facadeException;
		}

	}

	/**
	 * this method create a new Customer, it will first check that Customer with
	 * the same name doesn't already exist, only logged in Admin will be able to
	 * use this method
	 * 
	 * @param Customer
	 *            is the Customer Object to create
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin
	 * @throws FacadeException
	 * @throws FacadeException
	 *             - one of your customer parameters is null-please check it
	 * @throws FacadeException
	 *             - your Customer name length is invalid-name must be 3-50
	 *             characters
	 * @throws FacadeException
	 *             - your Customer password length is invalid-paswword must be
	 *             4-50 characters
	 * @throws FacadeException
	 *             - unable to create customer- customer name already exist in
	 *             DB
	 * @throws FacadeException
	 *             - you need to login as admin in order to create Customer
	 */
	public void createCustomer(Customer Customer) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			if (super.customerDBDAO.getCustomerByName(Customer.getCustName()) == null) {
				if (super.isValidCustomer(Customer)) {
					super.customerDBDAO.createCustomer(Customer);
					Customer.setId(super.customerDBDAO.getCustomerByName(Customer.getCustName()).getId());
				}
			} else {
				FacadeException facadeException = new FacadeException(
						"unable to create customer- customer name already exist in DB");
				throw facadeException;
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to create Customer");
			throw facadeException;
		}
	}

	/**
	 * this method removes/delete Customer, it will first check that Customer
	 * with the same name exist and will delete it, only logged in Admin will be
	 * able to use this method
	 * 
	 * @param Customer
	 *            is the Customer Object to remove
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin
	 * @throws FacadeException
	 *             - Unable to remove Customer, a Customer with that name or ID
	 *             does not exist
	 * @throws FacadeException
	 *             - you need to login as admin in order to remove Customer
	 */
	public void removeCustomer(Customer Customer) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			if (Customer.getCustName() != null) {
				super.customerDBDAO.removeCustomer(Customer);
			} else {
				FacadeException facadeException = new FacadeException(
						"Unable to remove Customer, a Customer with that name or ID does not exist");
				throw facadeException;
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to remove Customer");
			throw facadeException;
		}
	}

	/**
	 * this method updates Customer, it will first check that Customer with the
	 * same name exist and then update it, only logged in Admin will be able to
	 * use this method
	 * 
	 * @param Customer
	 *            is the Customer Object to update
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin
	 * @throws FacadeException
	 *             - Unable to update Customer, a Customer with that name or ID
	 *             does not exist
	 * @throws FacadeException
	 *             - you need to login as admin in order to update customer
	 * @throws FacadeException
	 *             - one of your customer parameters is null-please check it
	 * @throws FacadeException
	 *             - your Customer name length is invalid-name must be 3-50
	 *             characters
	 * @throws FacadeException
	 *             - your Customer password length is invalid-paswword must be
	 *             4-50 characters
	 */
	public void updateCustomer(Customer Customer) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			if (super.isValidCustomer(Customer)) {
				Customer last = super.customerDBDAO.getCustomerByName(Customer.getCustName());
				if (last == null) {
					FacadeException facadeException = new FacadeException(
							"Unable to update Customer, a Customer with that name or ID does not exist");
					throw facadeException;
				}
				if (Customer.getId() == last.getId() && Customer.getCustName().equals(last.getCustName())) {
					super.customerDBDAO.updateCustomer(Customer);
					;
				} else {
					FacadeException facadeException = new FacadeException(
							"Unable to update Customer, a Customer with that name or ID does not exist");
					throw facadeException;
				}
			}

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to update customer");
			throw facadeException;
		}
	}

	/**
	 * this method get java beans Customer object associated with the given id,
	 * only logged in Admin will be able to use this method
	 * 
	 * @param id
	 *            is the Customer id
	 * @return java beans Customer object associated with the given id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get customer
	 * @throws FacadeException
	 */
	public Customer getCustomer(long id) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			return super.ThisCustomer(id);
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to get customer");
			throw facadeException;
		}
	}

	/**
	 * this method get java beans all Customers Collection, only logged in Admin
	 * will be able to use this method
	 * 
	 * @return java beans all Customers Collection
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as admin in order to get All Customers
	 */
	public Collection<Customer> getAllCustomer() throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			return super.customerDBDAO.getAllCustomers();
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to get All Customers");
			throw facadeException;
		}
	}

	/**
	 * this method Deletes All Coupons that have expired, only logged in Admin
	 * will be able to use this method
	 * 
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as admin in order to get All Customers
	 */
	public void DeleteAllCouponsOutOfDate() throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Admin)) {
			for (Coupon UpToDateCoupon : super.couponDBDAO.getAllCoupons()) {
				if (!UpToDateCoupon.getEndDate().after(new java.sql.Date(new java.util.Date().getTime()))) {
					super.couponDBDAO.removeCoupon(UpToDateCoupon);
				}
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to get All Customers");
			throw facadeException;
		}

	}

}
