package Facade;

import java.sql.Date;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;

public class CompanyFacade extends Client implements CouponClientFacade {

	/**
	 * this method create a new Coupon Object, it will first check that Coupon
	 * with the same title doesn't already exist,only logged in Company will be
	 * able to use this method
	 * 
	 * @param Coupon
	 *            is the Coupon Object to create
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - unable to create Coupon- Coupon name already exist in DB
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 * @throws FacadeException
	 *             - one of your coupon parameters is null-please check it
	 * @throws FacadeException
	 *             - your Coupon title length is invalid-title must be 3-100
	 *             characters
	 * @throws FacadeException
	 *             - Coupon End date is not valid-date had expired
	 * @throws FacadeException
	 *             - Coupon Start date can not be after end date
	 * @throws FacadeException
	 *             - Coupon Amount is ivalid-must be over 0
	 * @throws FacadeException
	 *             - Coupon Price is ivalid-must be over 0
	 * @throws FacadeException
	 *             - invalid Coupon type name length- max length is 50
	 *             characters
	 * @throws FacadeException
	 *             - invalid Coupon message length- max length is 150 characters
	 * @throws FacadeException
	 *             - invalid Coupon image URL length- max length is 250
	 *             characters
	 */
	public void createCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			if (super.isValidCoupon(Coupon)) {

				if (super.couponDBDAO.getCouponByTitle(Coupon.getTitle()) == null
						&& super.couponDBDAO.getCoupon(Coupon.getId()) == null)

				{
					super.couponDBDAO.createCoupon(Coupon);
					Coupon.setId(super.couponDBDAO.getCouponByTitle(Coupon.getTitle()).getId());
					Company tempc = super.ThisCompany();
					super.companyDBDAO.CreateCoupon(Coupon, tempc);
					super.companyDBDAO.updateCompany(tempc);

					// super.companyDBDAO.CreateCoupon(Coupon,
					// super.ThisCompany());
				} else {
					FacadeException facadeException = new FacadeException(
							"unable to create Coupon- Coupon name already exist in DB");
					throw facadeException;
				}
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to create new coupon");
			throw facadeException;
		}

	}

	@Override
	public String toString() {

		try {
			return super.ThisCompany().toString();
		} catch (ConnectionPoolException | DAOException | FacadeException e) {
			e.printStackTrace();
			return e.toString();
		}

	}

	/**
	 * this method removes/delete Coupon, it will first check that Coupon with
	 * the same title exist and will delete it,only logged in company will be
	 * able to use this method
	 * 
	 * @param Coupon
	 *            is the Coupon Object to remove
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - remove failed- Coupon does not exist in DB
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 */
	public void removeCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			Coupon UpToDateCoupon = super.couponDBDAO.getCoupon(Coupon.getId());
			if (UpToDateCoupon == null) {
				FacadeException facadeException = new FacadeException("remove failed- Coupon does not exist in DB");
				throw facadeException;
			}
			if (super.couponDBDAO.CouponIsBelongToCompany(UpToDateCoupon, super.ThisCompany().getId())) {
				super.couponDBDAO.removeCoupon(UpToDateCoupon);
			} else {
				FacadeException facadeException = new FacadeException(
						"coupon can not be removed, this coupon does not belong to your company");
				throw facadeException;
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to remove coupon");
			throw facadeException;
		}

	}

	/**
	 * this method updates Coupon, it will first check that Coupon with the same
	 * title exist and then update it,only logged in Company will be able to use
	 * this method
	 * 
	 * @param Coupon
	 *            is the Coupon Object to update
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - coupon can not be updated, this coupon does not belong to
	 *             your company
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 * @throws FacadeException
	 *             - one of your coupon parameters is null-please check it
	 * @throws FacadeException
	 *             - your Coupon title length is invalid-title must be 3-100
	 *             characters
	 * @throws FacadeException
	 *             - Coupon End date is not valid-date had expired
	 * @throws FacadeException
	 *             - Coupon Start date can not be after end date
	 * @throws FacadeException
	 *             - Coupon Amount is ivalid-must be over 0
	 * @throws FacadeException
	 *             - Coupon Price is ivalid-must be over 0
	 * @throws FacadeException
	 *             - invalid Coupon type name length- max length is 50
	 *             characters
	 * @throws FacadeException
	 *             - invalid Coupon message length- max length is 150 characters
	 * @throws FacadeException
	 *             - invalid Coupon image URL length- max length is 250
	 *             characters
	 * @throws FacadeException
	 *             - update failed- Coupon does not exist in DB
	 */
	public void updateCoupon(Coupon Coupon) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {

			if (super.isValidCoupon(Coupon)) {
				Coupon UpToDateCoupon = super.couponDBDAO.getCoupon(Coupon.getId());
				if (UpToDateCoupon == null) {
					FacadeException facadeException = new FacadeException("update failed- Coupon does not exist in DB");
					throw facadeException;
				}
				if (super.couponDBDAO.CouponIsBelongToCompany(UpToDateCoupon, super.ThisCompany().getId())
						&& Coupon.getTitle().equals(UpToDateCoupon.getTitle())) {
					super.couponDBDAO.updateCoupon(Coupon);
				} else {
					FacadeException facadeException = new FacadeException(
							"coupon can not be updated, this coupon does not belong to your company");
					throw facadeException;
				}
			}

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to remove coupon");
			throw facadeException;
		}

	}

	/**
	 * this method get java beans Coupon object associated with the given id,
	 * only logged in Company will be able to use this method
	 * 
	 * @param id
	 *            is the Coupon id
	 * @return java beans Coupon object associated with the given id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - coupon can not be viewed, this coupon does not belong to
	 *             your company
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	public Coupon getCoupon(long id) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			Coupon UpToDateCoupon = super.couponDBDAO.getCoupon(id);
			if (super.couponDBDAO.CouponIsBelongToCompany(UpToDateCoupon, super.ThisCompany().getId())) {
				return UpToDateCoupon;
			} else {
				FacadeException facadeException = new FacadeException(
						"coupon can not be viewed, this coupon does not belong to your company");
				throw facadeException;
			}
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to get coupon");
			throw facadeException;
		}

	}

	/**
	 * this method get java beans Coupons Collection, only logged in Company
	 * will be able to use this method
	 * 
	 * @return java beans Coupons Collection
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	// public Collection<Coupon> getAllCoupon() throws ConnectionPoolException,
	// DAOException, FacadeException {
	// if (super.IsloginAs(ClientType.Company)) {
	// return super.ThisCompany().getCoupons();
	// } else {
	// FacadeException facadeException = new FacadeException(
	// "you need to login as company in order to get all coupons");
	// throw facadeException;
	// }
	// }

	public Collection<Coupon> getAllCoupon() throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			return getAllCouponsOfCompany(super.ThisCompany().getId());
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to get all coupons");
			throw facadeException;
		}
	}

	/**
	 * this method get java beans Coupons Collection of the given Coupon type,
	 * only logged in Company will be able to use this method
	 * 
	 * @param CouponType
	 *            is the type of coupon to provide
	 * @return java beans Coupons Collection of the given Coupon type
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	public Collection<Coupon> getAllCouponByType(CouponType CouponType)
			throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			Collection<Coupon> OfType = new HashSet<>();
			Iterator<Coupon> Iterator = this.getAllCoupon().iterator();
			while (Iterator.hasNext()) {
				Coupon Coupon = Iterator.next();
				if (Coupon.getType().equals(CouponType)) {
					OfType.add(Coupon);
				}
			}
			return OfType;
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to get all coupons");
			throw facadeException;
		}

	}

	/**
	 * this method get java beans Coupons Collection that will expire before the
	 * given date, only logged in Company will be able to use this method
	 * 
	 * @param date
	 *            is the last Date of expiration date of the coupons
	 * @return java beans Coupons Collection that will expire before the given
	 *         date
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	public Collection<Coupon> getAllCouponUntilDate(Date date)
			throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			Collection<Coupon> OfDate = new HashSet<>();
			Iterator<Coupon> Iterator = this.getAllCoupon().iterator();
			while (Iterator.hasNext()) {
				Coupon Coupon = Iterator.next();
				if (Coupon.getEndDate().before(date)) {
					OfDate.add(Coupon);
				}
			}
			return OfDate;
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to get all coupons");
			throw facadeException;
		}

	}

	/**
	 * this method will return the 'Object Company' of the Company that
	 * performed login
	 * 
	 * @return the 'Object Company' of the Company that performed login
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	public Company getCompanyDetails() throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Company)) {
			return super.ThisCompany();
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to get all coupons");
			throw facadeException;
		}

	}
}
