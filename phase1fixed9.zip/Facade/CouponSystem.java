package Facade;

import Data_Base.Connection_Pool;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;

public class CouponSystem {
	private static CouponSystem INSTANCE;

	private CouponSystem() {

	}

	/**
	 * this method will use the Object CouponSystem to return a single instance
	 * of the CouponSystem, the instance will be the reference for the single
	 * CouponSystem
	 * 
	 * @return a single instance of the CouponSystem
	 */
	public static CouponSystem getInstance() {
		if (INSTANCE == null) {
			INSTANCE = new CouponSystem();
		}
		return INSTANCE;
	}

	/**
	 * this method checks if the correct user name,password is entered for the
	 * client and returns a new Object of the Client type logged in correct
	 * 
	 * @param name
	 *            is the user name of the client
	 * @param pass
	 *            is the password of the client
	 * @param type
	 *            is the client type logged in
	 * @return a new Object of the Client type logged in
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 */
	public Client login(String name, String pass, ClientType type)
			throws ConnectionPoolException, DAOException, FacadeException {
		Client c = null;
		switch (type) {
		case Customer:
			c = new CustomerFacade();
			break;
		case Company:
			c = new CompanyFacade();
			break;
		case Admin:
			c = new AdminFacade();
			break;
		}
		if (c != null) {
			// System.out.println("hello" + c.login(name, pass, type));
			if (c.login(name, pass, type)) {
				return c;
			} else {
				FacadeException facadeException = new FacadeException("user does not exist");
				throw facadeException;
			}
		} else {
			FacadeException facadeException = new FacadeException("client type does not exist");
			throw facadeException;
		}
	}

	/**
	 * this method will shut down the Coupon single system,before that it will
	 * first close all opened connections
	 * 
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 */
	public void shutdown() throws ConnectionPoolException {
		Connection_Pool p = Connection_Pool.getInstance();
		p.closeAllConnections();
	}
}


