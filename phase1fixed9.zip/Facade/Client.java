package Facade;

import java.util.Collection;
import java.util.HashSet;

import DBDAO.CompanyDBDAO;
import DBDAO.CouponDBDAO;
import DBDAO.CustomerDBDAO;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import java_beans.Company;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class Client {

	protected static CompanyDBDAO companyDBDAO = new CompanyDBDAO();
	protected static CustomerDBDAO customerDBDAO = new CustomerDBDAO();
	protected static CouponDBDAO couponDBDAO = new CouponDBDAO();
	private String userName;
	private String password;
	private ClientType clientType;
	private boolean LogedIn;

	/**
	 * this method checks if the Object Coupon is valid, it will check for the
	 * following- coupon parameters are not null,Coupon title length between
	 * 3-100 characters,end date cannot be expired,Start date can not be after
	 * end date,Coupon Amount is over 0,Coupon Price is over 0,Coupon type name
	 * length under 50 characters, Coupon message length under 150 characters,
	 * Coupon image URL length under 250 characters
	 * 
	 * @param coupon
	 *            is the Object Coupon to check its validity
	 * @return true for valid coupon and throws exceptions for invalid Coupon
	 * @throws FacadeException
	 *             - one of your coupon parameters is null-please check it
	 * @throws FacadeException
	 *             - your Coupon title length is invalid-title must be 3-100
	 *             characters
	 * @throws FacadeException
	 *             - Coupon End date is not valid-date had expired
	 * @throws FacadeException
	 *             - Coupon Start date can not be after end date
	 * @throws FacadeException
	 *             - Coupon Amount is invalid-must be over 0
	 * @throws FacadeException
	 *             - Coupon Price is invalid-must be over 0
	 * @throws FacadeException
	 *             - invalid Coupon type name length- max length is 50
	 *             characters
	 * @throws FacadeException
	 *             - invalid Coupon message length- max length is 150 characters
	 * @throws FacadeException
	 *             - invalid Coupon image URL length- max length is 250
	 *             characters
	 */
	public boolean isValidCoupon(Coupon coupon) throws FacadeException {
		if (coupon.getMessage() == null || coupon.getTitle() == null || coupon.getType() == null) {
			FacadeException facadeException = new FacadeException(
					"one of your coupon parameters is null-please check it");
			throw facadeException;
		}
		if (coupon.getTitle().length() > 100 || coupon.getTitle().length() < 3) {
			FacadeException facadeException = new FacadeException(
					"your Coupon title length is invalid-title must be 3-100 characters");
			throw facadeException;
		}
		if (!coupon.getEndDate().after(new java.sql.Date(new java.util.Date().getTime()))) {
			FacadeException facadeException = new FacadeException("Coupon End date is not valid-date had expired ");
			throw facadeException;
		}
		// TODO delete in the if below the ! mark
		if (coupon.getStartDate().after(coupon.getEndDate())) {
			FacadeException facadeException = new FacadeException("Coupon Start date can not be after end date ");
			throw facadeException;
		}

		if (coupon.getAmount() < 0) {
			FacadeException facadeException = new FacadeException("Coupon Amount is ivalid-must be over 0");
			throw facadeException;
		}
		if (coupon.getPrice() < 0) {
			FacadeException facadeException = new FacadeException("Coupon Price is ivalid-must be over 0");
			throw facadeException;
		}

		if (coupon.getType().toString().length() > 50) {
			FacadeException facadeException = new FacadeException(
					"invalid Coupon type name length- max length is 50 characters");
			throw facadeException;
		}

		if (coupon.getMessage().length() > 150) {
			FacadeException facadeException = new FacadeException(
					"invalid Coupon message length- max length is 150 characters");
			throw facadeException;
		}

		if (coupon.getImage().length() > 250) {
			FacadeException facadeException = new FacadeException(
					"invalid Coupon image URL length- max length is 250 characters");
			throw facadeException;
		}
		return true;
	}

	/**
	 * this method checks if the Object Customer is valid, it will check for the
	 * following- Customer parameters are not null, Customer name length between
	 * 3-50 characters, Customer password length between 4-50 characters
	 * 
	 * @param customer
	 *            is the Object Customer to check its validity
	 * @return true for valid Customer and throws exceptions for invalid
	 *         Customer
	 * @throws FacadeException
	 *             - one of your customer parameters is null-please check it
	 * @throws FacadeException
	 *             - your Customer name length is invalid-name must be 3-50
	 *             characters
	 * @throws FacadeException
	 *             - your Customer password length is invalid-password must be
	 *             4-50 characters
	 */
	public boolean isValidCustomer(Customer customer) throws FacadeException {
		if (customer.getCustName() == null || customer.getPassword() == null) {
			FacadeException facadeException = new FacadeException(
					"one of your customer parameters is null-please check it");
			throw facadeException;
		}
		if (customer.getCustName().length() > 50 || customer.getCustName().length() < 3) {
			FacadeException facadeException = new FacadeException(
					"your Customer name length is invalid-name must be 3-50 characters");
			throw facadeException;
		}

		if (customer.getPassword().length() < 4 || (customer.getPassword().length() > 50)) {
			FacadeException facadeException = new FacadeException(
					"your Customer password length is invalid-paswword must be 4-50 characters");
			throw facadeException;
		}

		return true;
	}

	/**
	 * this method checks if the Object Company is valid, it will check for the
	 * following- Company parameters are not null, Company name length between
	 * 3-50 characters, Company email validity, Company password length between
	 * 4-50 characters
	 * 
	 * @param company
	 *            is the Object Company to check its validity
	 * @return true for valid Company and throws exceptions for invalid Company
	 * @throws FacadeException
	 *             - one of your Company parameters is null-please check it
	 * @throws FacadeException
	 *             - your Company name length is invalid-name must be 3-50
	 *             characters
	 * @throws FacadeException
	 *             - your Company email is not valid
	 * @throws FacadeException
	 *             - throw exception invalid password
	 */
	public boolean isValidCompany(Company company) throws FacadeException {
		if (company.getCompName() == null || company.getEmail() == null || company.getPassword() == null) {
			FacadeException facadeException = new FacadeException(
					"one of your Company parameters is null-please check it");
			throw facadeException;
		}
		if (company.getCompName().length() > 50 || company.getCompName().length() < 3) {
			FacadeException facadeException = new FacadeException(
					"your Company name length is invalid-name must be 3-50 characters");
			throw facadeException;
		}

		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		java.util.regex.Matcher m = p.matcher(company.getEmail());
		if (!m.matches() && (company.getEmail().length() > 50)) {

			FacadeException facadeException = new FacadeException("your Company email is not valid");
			throw facadeException;
		}

		if (company.getPassword().length() < 4 || (company.getPassword().length() > 50)) {
			FacadeException facadeException = new FacadeException("throw exception invalid password");
			throw facadeException;

		}

		return true;
	}

	/**
	 * this method will return the 'Object Company' of the Company that
	 * performed login
	 * 
	 * @return the 'Object Company' that performed login
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as company in order to get company
	 */
	public Company ThisCompany() throws ConnectionPoolException, DAOException, FacadeException {
		if (clientType.compareTo(ClientType.Company) == 0 && LogedIn) {
			return companyDBDAO.getCompenyByName(userName);

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as company in order to get company");
			throw facadeException;
		}
	}

	/**
	 * this method will return the 'Object Company' of the Company with the
	 * given name, only logged in Admin will be able to use this method
	 * 
	 * @param name
	 *            is the Company name to get
	 * @return the 'Object Company' of the Company with the given name
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get company
	 */
	public Company ThisCompany(String name) throws ConnectionPoolException, DAOException, FacadeException {
		if (clientType.compareTo(ClientType.Admin) == 0 && LogedIn) {
			return companyDBDAO.getCompenyByName(name);

		} else {
			FacadeException facadeException = new FacadeException("you need to login as admin in order to get company");
			throw facadeException;
		}
	}

	/**
	 * this method will return the 'Object Company' of the Company with the
	 * given id, only logged in Admin will be able to use this method
	 * 
	 * @param id
	 *            is the Company id to get
	 * @return the 'Object Company' of the Company with the given id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get company
	 */
	public Company ThisCompany(long id) throws ConnectionPoolException, DAOException, FacadeException {
		if (clientType.compareTo(ClientType.Admin) == 0 && LogedIn) {
			return companyDBDAO.getCompany(id);

		} else {
			FacadeException facadeException = new FacadeException("you need to login as admin in order to get company");
			throw facadeException;
		}
	}

	/**
	 * this method will return the 'Object Customer' of the Customer that
	 * performed login
	 * 
	 * @return the 'Object Customer' of the Customer that performed login
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as customer in order to get customer
	 */
	public Customer ThisCustomer() throws ConnectionPoolException, DAOException, FacadeException {
		if (clientType.compareTo(ClientType.Customer) == 0 && LogedIn) {
			return customerDBDAO.getCustomerByName(userName);

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as customer in order to get details");
			throw facadeException;
		}
	}

	/**
	 * this method will return the 'Object Customer' of the Customer with the
	 * given name, only logged in Admin will be able to use this method
	 * 
	 * @param name
	 *            is the Customer name to get
	 * @return the 'Object Customer' of the Customer with the given name
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get customer
	 */
	public Customer ThisCustomer(String name) throws ConnectionPoolException, DAOException, FacadeException {
		if (clientType.compareTo(ClientType.Admin) == 0 && LogedIn) {
			return customerDBDAO.getCustomerByName(name);

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to get customer details");
			throw facadeException;
		}
	}

	/**
	 * this method will return the 'Object Customer' of the Customer with the
	 * given id, only logged in Admin will be able to use this method
	 * 
	 * @param id
	 *            is the Customer id to get
	 * @return the 'Object Customer' of the Customer with the given id
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get customer
	 */
	public Customer ThisCustomer(long id) throws ConnectionPoolException, DAOException, FacadeException {
		if (clientType.compareTo(ClientType.Admin) == 0 && LogedIn) {
			return customerDBDAO.getCustomer(id);

		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as admin in order to get customer details");
			throw facadeException;
		}
	}

	/**
	 * this method checks if the correct user name,password is entered for the
	 * correct client type and returns a 'LogedIn' flag when credentials are
	 * correct
	 * 
	 * @param userName
	 *            is the user name to enter
	 * @param password
	 *            is the password to enter
	 * @param clientType
	 *            is the type of client that perform the login- a customer, a
	 *            company or an admin
	 * @return 'LogedIn' flag when the correct user name,password is entered for
	 *         the correct client type
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 */
	public boolean login(String userName, String password, ClientType clientType)
			throws ConnectionPoolException, DAOException, FacadeException {
		this.clientType = clientType;
		this.userName = userName;
		this.password = password;
		switch (clientType) {
		case Customer:
			LogedIn = customerDBDAO.login(userName, password);
			return LogedIn;
		case Company:
			LogedIn = companyDBDAO.login(userName, password);
			return LogedIn;

		case Admin:
			LogedIn = (userName.equals("admin") && password.equals("1234"));
			return LogedIn;
		}
		FacadeException facadeException = new FacadeException(
				"check your login credentials ,your user name, password or user role is incorect");
		throw facadeException;

	}

	/**
	 * this method checks what type of client has logged in and returns a
	 * 'LogedIn' flag
	 * 
	 * @param clientType
	 *            is the type of client that perform the login- a customer, a
	 *            company or an admin
	 * @return a 'LogedIn' flag
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 */
	public boolean IsloginAs(ClientType clientType) throws FacadeException {
		if (clientType.equals(this.clientType)) {
			return LogedIn;
		}
		FacadeException facadeException = new FacadeException(
				"check your login credentials ,your user name, password or user role is incorect");
		throw facadeException;

	}

	/**
	 * this method returns a collection of coupons that exist in DB
	 * 
	 * @return a collection of coupons that exist in DB
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 */
	public Collection<Coupon> getAllCoupons() throws ConnectionPoolException, DAOException {
		return this.couponDBDAO.getAllCoupons();
	}

	/**
	 * this method returns the Object Coupon that has this Coupon ID
	 * 
	 * @param id
	 *            is the Coupon id to provide
	 * @return a Coupon Object
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 */
	public Coupon getCouponById(long id) throws ConnectionPoolException, DAOException {
		return this.couponDBDAO.getCoupon(id);
	}

	/**
	 * this method looks for a coupon that has this title and returns the Object
	 * Coupon with that title
	 * 
	 * @param Title
	 *            is the title/name of the coupon
	 * @return the Object Coupon that has this title
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 */
	public Coupon getCouponByTitle(String Title) throws ConnectionPoolException, DAOException {
		return this.couponDBDAO.getCouponByTitle(Title);
	}

	/**
	 * this method looks for all the coupons that belongs to a specific Company
	 * (by Company id) and returns that Company collection of coupons
	 * 
	 * @param id
	 *            is the company id
	 * @return a collection of coupons that belongs the that company
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 */
	public Collection<Coupon> getAllCouponsOfCompany(long id) throws ConnectionPoolException, DAOException {
		return this.companyDBDAO.getCouponsPerCompany(id);
	}

	/**
	 * this method looks for all the coupons from a specific type and returns a
	 * collection of coupons of that Type
	 * 
	 * @param couponType
	 *            is the type of coupon to get
	 * @return a collection of coupons of the given Type
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 */
	public Collection<Coupon> getAllCouponsByType(CouponType couponType) throws ConnectionPoolException, DAOException {
		return this.couponDBDAO.getCouponByType(couponType);
	}

	/**
	 * looks for all the coupons that belongs to a this company that their cost
	 * is below the given price and returns a collection of coupons
	 * 
	 * @param price
	 *            is the max price of coupon to search
	 * @param id
	 *            is the customer id that purchased the coupons
	 * @return a collection of coupons below a specific price and belongs to a
	 *         specific Customer
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get all coupon by
	 *             price of customer
	 */
	public Collection<Coupon> getAllCouponByPriceOfCompId(double price, long id)
			throws ConnectionPoolException, DAOException, FacadeException {
		Collection<Coupon> coupons = new HashSet<>();
		for (Coupon c : this.ThisCompany(id).getCoupons()) {
			if (c.getPrice() < price) {
				coupons.add(c);
			}
		}
		return coupons;
		// return this.couponDBDAO.getAllCouponsByPrice(price, id);
	}

	/**
	 * looks for all the coupons that belongs to a this company that their cost
	 * is below the given price and returns a collection of coupons
	 * 
	 * @param price
	 *            is the max price of coupon to search
	 * @param id
	 *            is the customer id that purchased the coupons
	 * @return a collection of coupons below a specific price and belongs to a
	 *         specific Customer
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as company in order to get all coupon by
	 *             price of customer
	 */
	public Collection<Coupon> getAllCouponByPriceOfCompId(double price)
			throws ConnectionPoolException, DAOException, FacadeException {
		Collection<Coupon> coupons = new HashSet<>();
		for (Coupon c : this.ThisCompany().getCoupons()) {
			if (c.getPrice() < price) {
				coupons.add(c);
			}
		}
		return coupons;
		// return this.couponDBDAO.getAllCouponsByPrice(price, id);
	}

	/**
	 * looks for all the coupons that belongs to a this Customer that their cost
	 * is below the given price and returns a collection of coupons
	 * 
	 * @param price
	 *            is the max price of coupon to search
	 * @param id
	 *            is the customer id that purchased the coupons
	 * @return a collection of coupons below a specific price and belongs to a
	 *         specific Customer
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as customer in order to get all coupon by
	 *             price of customer
	 */
	public Collection<Coupon> getAllPurchasedCouponsByPrice(double price)
			throws ConnectionPoolException, DAOException, FacadeException {
		Collection<Coupon> coupons = new HashSet<>();
		for (Coupon c : this.ThisCustomer().getCoupons()) {
			if (c.getPrice() < price) {
				coupons.add(c);
			}
		}
		return coupons;
		// return this.couponDBDAO.getAllCouponsByPrice(price, id);
	}

	/**
	 * looks for all the coupons that their cost is below the given price and
	 * returns a collection of coupons
	 * 
	 * @param price
	 *            is the max price of coupon to search
	 * @param id
	 *            is the customer id that purchased the coupons
	 * @return a collection of coupons below a specific price and belongs to a
	 *         specific Customer
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * 
	 */
	public Collection<Coupon> getAllCouponByPrice(double price, long id) throws ConnectionPoolException, DAOException {
		return this.couponDBDAO.getAllCouponsByPrice(price);
	}

	/**
	 * looks for all the coupons that belongs to a specific Customer that their
	 * cost is below the given price and returns a collection of coupons
	 * 
	 * @param price
	 *            is the max price of coupon to search
	 * @param id
	 *            is the customer id that purchased the coupons
	 * @return a collection of coupons below a specific price and belongs to a
	 *         specific Customer
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as Admin in order to get all coupon by
	 *             price of customer
	 */
	public Collection<Coupon> getAllCouponByPriceOfCustId(double price, long id)
			throws ConnectionPoolException, DAOException, FacadeException {
		Collection<Coupon> coupons = new HashSet<>();
		for (Coupon c : this.ThisCustomer(id).getCoupons()) {
			if (c.getPrice() < price) {
				coupons.add(c);
			}
		}
		return coupons;
		// return this.couponDBDAO.getAllCouponsByPrice(price, id);
	}

	public String getUserName() {
		return userName;
	}

	public String getPassword() {
		return password;
	}

}
