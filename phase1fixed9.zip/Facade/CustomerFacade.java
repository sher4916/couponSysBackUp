package Facade;

import java.util.Collection;

import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;
import java_beans.Coupon;
import java_beans.CouponType;
import java_beans.Customer;

public class CustomerFacade extends Client implements CouponClientFacade {
	// private Customer
	public CustomerFacade() {
	}

	@Override
	public String toString() {
		try {
			return super.ThisCustomer().toString();
		} catch (ConnectionPoolException | DAOException | FacadeException e) {
			e.printStackTrace();
			return e.toString();
		}
	}

	/**
	 * this method checks that user is logged in as a Customer and will perform
	 * purchase that will indicate that the coupon now belongs to the Customer,
	 * the purchase will fail in the following cases- Coupon date has expired,
	 * Coupon is out of stock (amount=0), same coupon already belongs to this
	 * Customer
	 * 
	 * @param coupon
	 *            is the specific Coupon to buy
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - purchase failed- a Customer can not buy more than 1 of the
	 *             same coupon
	 * @throws FacadeException
	 *             - purchase failed- a Customer can not buy expired coupon
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 * @throws FacadeException
	 *             - purchase failed- Coupon does not exist in DB
	 */
	public void purchaseCoupon(Coupon coupon) throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Customer)) {
			Coupon UpToDateCoupon = super.couponDBDAO.getCoupon(coupon.getId());
			if (UpToDateCoupon == null) {
				FacadeException facadeException = new FacadeException("purchase failed- Coupon does not exist in DB");
				throw facadeException;
			}
			if (UpToDateCoupon.getEndDate().after(new java.sql.Date(new java.util.Date().getTime()))) {
				// TODO shahaf- where is the exception that this coupon is out
				// of stock (amount=0)
				if (UpToDateCoupon.getAmount() > 0) {
					/*
					 * for(Coupon c:super.ThisCustomer().getCoupons()) {
					 * if(!coupon.equals(c)) {
					 * 
					 * } else { FacadeException facadeException = new
					 * FacadeException(
					 * "purchase failed- a Customer can not buy more than 1 of the same coupon"
					 * ); throw facadeException; } }
					 */

					if (!super.couponDBDAO.CouponIsBelongToCustomer(UpToDateCoupon, super.ThisCustomer().getId())) {
						super.customerDBDAO.purchaseCoupon(UpToDateCoupon, super.ThisCustomer());
						UpToDateCoupon.setAmount(UpToDateCoupon.getAmount() - 1);
						super.couponDBDAO.updateCoupon(UpToDateCoupon);
					} else {
						FacadeException facadeException = new FacadeException(
								"purchase failed- a Customer can not buy more than 1 of the same coupon");
						throw facadeException;
					}

				}
			} else {
				super.couponDBDAO.removeCoupon(UpToDateCoupon);
				FacadeException facadeException = new FacadeException(
						"purchase failed- a Customer can not buy expired coupon");
				throw facadeException;

			}
		} else

		{
			FacadeException facadeException = new FacadeException(
					"you need to login as customer in order to purchase coupon");
			throw facadeException;

		}
	}

	public Collection<Coupon> getAvialableCouponsForPurchase()
			throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Customer)) {
			return super.customerDBDAO.getAvialableCouponsForPurchase(super.ThisCustomer());
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as customer in order to view all Avialable Coupons For Purchase");
			throw facadeException;

		}
	}

	/**
	 * this method get java beans Coupons Collection that belong to the logged
	 * in Customer, only logged in Customer will be able to use this method
	 * 
	 * @return java beans Coupons Collection that belong to the logged in
	 *         Customer,
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - you need to login as customer
	 */
	public Collection<Coupon> getAllPurchasedCoupons() throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Customer)) {
			return super.customerDBDAO.getCouponsPerCustomer(super.ThisCustomer().getId());
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as customer in order to view all purchased coupons");
			throw facadeException;

		}
	}

	/**
	 * this method get java beans Coupons Collection that belong to the logged
	 * in Customer and is from the given Coupon Type, only logged in Customer
	 * will be able to use this method
	 * 
	 * @param type
	 *            is the Coupon Type you wish the get
	 * @return java beans Coupons Collection that belong to the logged in
	 *         Customer and is from the given Coupon Type
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	public Collection<Coupon> getAllPurchasedCouponsByType(CouponType type)
			throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Customer)) {
			return super.couponDBDAO.getAllCouponsPerCustIDByType(super.ThisCustomer().getId(), type);
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as customer in order to view all purchased coupons");
			throw facadeException;

		}
	}
	/*
	 * /** this method get java beans Coupons Collection that belong to the
	 * logged in Customer and that Coupon price is below the given price, only
	 * logged in Customer will be able to use this method
	 * 
	 * @param price is up to the Coupon price you wish to get
	 * 
	 * @return java beans Coupons Collection that belong to the logged in
	 * Customer and that Coupon price is below the given price
	 * 
	 * @throws ConnectionPoolException - Connection Pool has been interrupted
	 * 
	 * @throws DAOException -you might have a connection or Query problem,
	 * please check your url path and your Query
	 * 
	 * @throws FacadeException - you need to login as customer
	 * 
	 * @throws FacadeException - check your login credentials ,your user name,
	 * password or user role is incorect
	 */
	/*
	 * public Collection<Coupon> getAllPurchasedCouponsByPrice(Double price)
	 * throws ConnectionPoolException// it , DAOException, FacadeException { if
	 * (super.IsloginAs(ClientType.Customer)) { return
	 * super.couponDBDAO.getAllCouponsByPrice(price,
	 * super.ThisCustomer().getId()); } else { FacadeException facadeException =
	 * new FacadeException(
	 * "you need to login as customer in order to view all purchased coupons");
	 * throw facadeException;
	 * 
	 * }
	 * 
	 * }
	 */

	/**
	 * this method will return the 'Object Customer' of the Customer that
	 * performed login
	 * 
	 * @return the 'Object Customer' of the Customer that performed login
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorect
	 */
	public Customer getCustomerDetails() throws ConnectionPoolException, DAOException, FacadeException {
		if (super.IsloginAs(ClientType.Customer)) {
			return super.ThisCustomer();
		} else {
			FacadeException facadeException = new FacadeException(
					"you need to login as customer in order to get Customer details");
			throw facadeException;
		}

	}
}
