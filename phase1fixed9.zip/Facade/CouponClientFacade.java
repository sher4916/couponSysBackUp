package Facade;

public interface CouponClientFacade {

}
