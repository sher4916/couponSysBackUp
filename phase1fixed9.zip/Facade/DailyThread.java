package Facade;

import java.util.Date;

import Data_Base.Connection_Pool;
import Exceptions.ConnectionPoolException;
import Exceptions.DAOException;
import Exceptions.FacadeException;

public class DailyThread extends Thread implements Runnable {

	private AdminFacade admin;
	private boolean close = true;
	// private Object ob = new Object();
	private Connection_Pool connectio_Pool;
	private Thread RunningThread;
	public long interval;

	/**
	 * this method prepares the Daily Thread to run using the admin user name
	 * and password
	 * 
	 * @param userName
	 *            is admin user name
	 * @param password
	 *            is admin password
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 */
	public DailyThread(String userName, String password) throws ConnectionPoolException, DAOException, FacadeException {
		super();
		connectio_Pool = Connection_Pool.getInstance();
		CouponSystem Csys = CouponSystem.getInstance();
		admin = (AdminFacade) Csys.login(userName, password, ClientType.Admin);
		interval = 86400000;
	}

	/**
	 * this method prepares the Daily Thread to run every given interval using
	 * the admin user name and password
	 * 
	 * @param userName
	 *            is admin user name
	 * @param password
	 *            is admin password
	 * @param interval
	 *            is the break between each activation of the method which will
	 *            delete expired Coupons
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 * @throws DAOException
	 *             -you might have a connection or Query problem, please check
	 *             your url path and your Query
	 * @throws FacadeException
	 *             - check your login credentials ,your user name, password or
	 *             user role is incorrect
	 */
	public DailyThread(String userName, String password, long interval)
			throws ConnectionPoolException, DAOException, FacadeException {
		super();
		connectio_Pool = Connection_Pool.getInstance();
		admin.login(userName, password, ClientType.Admin);
		this.interval = interval;
	}

	@Override
	public void run() {
		this.close = false;
		Date s = new Date();
		while (!this.close) {
			try {
				RunningThread = super.currentThread();
				try {

					System.out.println("------------------deliting all expiered coupons------------------");
					admin.DeleteAllCouponsOutOfDate();
					Date temp = new Date();
					super.sleep(interval - (temp.getTime() - s.getTime()));
					/*
					 * synchronized (ob) { ob.wait(interval - (temp.getTime() -
					 * s.getTime())); }
					 */
					s = new Date(s.getTime() + interval);
				} catch (InterruptedException e1) {
					this.close = true;
				}

			} catch (ConnectionPoolException | DAOException | FacadeException e) {
				e.printStackTrace();
				this.close = true;

			}
		}

		try {
			this.connectio_Pool.closeAllConnections();
		} catch (ConnectionPoolException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out.println("closing connection pool");

	}

	/**
	 * this method will close the Coupon System
	 * 
	 * @throws ConnectionPoolException
	 *             - Connection Pool has been interrupted
	 */
	public void ShutDown() throws ConnectionPoolException {
		this.close = true;
		/*
		 * synchronized (ob) { ob.notifyAll();
		 * 
		 * }
		 */
		RunningThread.interrupt();
		this.connectio_Pool.closeAllConnections();
	}

}
