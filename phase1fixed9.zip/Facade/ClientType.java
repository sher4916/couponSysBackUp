package Facade;

import java.io.Serializable;

public enum ClientType implements Serializable {
	Admin, Company, Customer;

}
