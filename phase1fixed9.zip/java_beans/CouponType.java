package java_beans;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * this is the Enum options on which the type of category the Coupon describes
 *
 */
@XmlRootElement

public enum CouponType implements Serializable {

	RESTURANTS, ELECTRICITY, FOOD, HEALTH, SPORTS, CAMPING, TRAVELLING;

}
