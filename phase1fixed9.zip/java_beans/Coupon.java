package java_beans;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlRootElement;;

@XmlRootElement
public class Coupon implements Serializable {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + amount;
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((image == null) ? 0 : image.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Coupon other = (Coupon) obj;
		if (amount != other.amount)
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (id != other.id)
			return false;
		if (image == null) {
			if (other.image != null)
				return false;
		} else if (!image.equals(other.image))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (type != other.type)
			return false;
		return true;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String title;
	private Date startDate;
	private Date endDate;
	private int amount;
	private CouponType type;
	private String message;
	private double price;
	private String image;

	/**
	 * this is the constructor to build the Object Coupon
	 */
	public Coupon() {

	}

	/**
	 * this is the constructor to build the Object Coupon
	 * 
	 * @param id
	 *            this is a unique id for the Coupon
	 * @param title
	 *            this is a unique title for the Coupon
	 * @param startDate
	 *            is the Start Date on which from it the Coupon is valid
	 * @param endDate
	 *            is the expiration date of the Coupon
	 * @param amount
	 *            is the amount of Coupons exist to sell of the same id
	 * @param type
	 *            is the category which the coupon belongs to, there are enum
	 *            option in Coupon Type class-RESTURANTS, ELECTRICITY, FOOD,
	 *            HEALTH, SPORTS, CAMPING, TRAVELLING;
	 * @param message
	 *            is the description of the Coupon
	 * @param price
	 *            is the purchase price of the Coupon
	 * @param image
	 *            is the Coupon visibility in an image
	 */
	public Coupon(long id, String title, Date startDate, Date endDate, int amount, CouponType type, String message,
			double price, String image) {
		super();
		this.id = id;
		this.title = title;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.type = type;
		this.message = message;
		this.price = price;
		this.image = image;
	}

	/**
	 * this is the constructor to build the Object Coupon
	 * 
	 * @param title
	 *            this is a unique title for the Coupon
	 * @param startDate
	 *            is the Start Date on which from it the Coupon is valid
	 * @param endDate
	 *            is the expiration date of the Coupon
	 * @param amount
	 *            is the amount of Coupons exist to sell of the same id
	 * @param type
	 *            is the category which the coupon belongs to, there are enum
	 *            option in Coupon Type class-RESTURANTS, ELECTRICITY, FOOD,
	 *            HEALTH, SPORTS, CAMPING, TRAVELLING;
	 * @param message
	 *            is the description of the Coupon
	 * @param price
	 *            is the purchase price of the Coupon
	 * @param image
	 *            is the Coupon visibility in an image
	 */
	public Coupon(String title, Date startDate, Date endDate, int amount, CouponType type, String message, double price,
			String image) {
		super();
		this.title = title;
		this.startDate = startDate;
		this.endDate = endDate;
		this.amount = amount;
		this.type = type;
		this.message = message;
		this.price = price;
		this.image = image;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getType() {
		return type.toString();
	}

	public void setType(String type) {
		this.type = CouponType.valueOf(type);
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "Coupon [id=" + id + ", title=" + title + ", startDate=" + startDate + ", endDate=" + endDate
				+ ", amount=" + amount + ", type=" + type + ", message=" + message + ", price=" + price + ", image="
				+ image + "]";
	}

}
